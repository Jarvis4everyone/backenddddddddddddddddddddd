"""
AURA Backend API - FastAPI Application
Main entry point for the AURA chatbot backend service.
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from contextlib import asynccontextmanager
import asyncio
import json
import os
from typing import Optional
from datetime import datetime
from dotenv import load_dotenv
from pydantic import BaseModel

# Load environment variables
load_dotenv()

# Import our services
from services.chat_service import ChatService
from services.learning_service import LearningService
from services.tts_service import tts_service
from models.chat_models import WebSocketMessage
from utils.logger import logger
from Chatbot.MongoDBService import MongoDBService

# Global services
chat_service = None
learning_service = None
mongodb_service = None

# Pydantic models
class TTSRequest(BaseModel):
    text: str
    voice: Optional[str] = "ash"  # Updated default to ash voice (changed from alloy)
    rate: Optional[str] = "+20%"  # Default to 120% speed
    pitch: Optional[str] = "+0Hz"
    volume: Optional[str] = "+0%"

async def keep_alive_ping(websocket: WebSocket):
    """Send periodic ping messages to keep WebSocket connection alive."""
    try:
        while True:
            await asyncio.sleep(30)  # Send ping every 30 seconds
            try:
                # Send a simple ping message
                ping_msg = {"type": "ping", "timestamp": asyncio.get_event_loop().time()}
                await websocket.send_text(json.dumps(ping_msg))
                logger.debug("🏓 Sent keep-alive ping")
            except Exception as e:
                logger.warning(f"🏓 Keep-alive ping failed: {str(e)}")
                # Connection closed, exit the task
                break
    except asyncio.CancelledError:
        # Task was cancelled, exit gracefully
        logger.debug("🏓 Keep-alive ping task cancelled")
        pass

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager for startup and shutdown."""
    global chat_service, learning_service, mongodb_service
    
    # Startup
    logger.startup("Starting AURA Backend API...")
    
    # Initialize MongoDB Service
    try:
        mongodb_service = MongoDBService()
        logger.success("MongoDB Service initialized")
    except Exception as e:
        logger.error(f"MongoDB Service initialization failed: {str(e)}")
        raise e
    
    # Initialize Learning Service
    try:
        learning_service = LearningService()
        logger.success("Learning Service initialized")
    except Exception as e:
        logger.warning(f"Learning Service initialization failed: {str(e)}")
        learning_service = None
    
    # Initialize Chat Service
    try:
        chat_service = ChatService(learning_service)
        logger.success("Chat Service initialized")
    except Exception as e:
        logger.error(f"Chat Service initialization failed: {str(e)}")
        raise e
    
    logger.success("AURA Backend API ready!")
    
    yield
    
    # Shutdown
    logger.shutdown("Shutting down AURA Backend API...")
    if chat_service:
        await chat_service.cleanup()
    logger.success("AURA Backend API shutdown complete!")

# Create FastAPI app
app = FastAPI(
    title="AURA Backend API",
    description="Backend API for AURA truck service chatbot system",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://aura-pw2p.onrender.com",  # Frontend URL
        "http://localhost:3000",  # Local development
        "http://localhost:3001",  # Alternative local port
        "http://127.0.0.1:3000",  # Local IP
        "http://127.0.0.1:3001",  # Alternative local IP
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "AURA Backend API - Truck Service Chatbot System",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "websocket_regular": "/ws/regular",
            "websocket_modify": "/ws/modify",
            "health": "/health",
            "api": {
                "get_all_requests": "/api/requests",
                "get_requests_count": "/api/requests/count",
                "get_requests_by_status": "/api/requests/status/{status}",
                "text_to_speech": "/api/tts",
                "fast_text_to_speech": "/api/tts/fast",
                "get_available_voices": "/api/tts/voices"
            }
        },
        "features": [
            "WebSocket-based chatbot communication",
            "Customer request management",
            "MongoDB data persistence",
            "AI-powered responses with OpenAI",
            "Request status tracking",
            "Pagination support",
            "Text-to-Speech with EdgeTTS",
            "Canadian English voice (en-CA-LiamNeural)"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "services": {
            "chat_service": chat_service is not None,
            "learning_service": learning_service is not None,
            "mongodb_service": mongodb_service is not None
        }
    }

@app.get("/api/requests")
async def get_all_customer_requests(
    limit: int = 100,
    skip: int = 0,
    status: str = None
):
    """
    Get all customer requests with optional filtering and pagination.
    
    Args:
        limit: Maximum number of requests to return (default: 100)
        skip: Number of requests to skip for pagination (default: 0)
        status: Filter by status (optional)
    
    Returns:
        JSON response with customer requests and metadata
    """
    try:
        if not mongodb_service:
            logger.error("MongoDB service not available")
            return {
                "error": "MongoDB service not available",
                "requests": [],
                "total_count": 0,
                "limit": limit,
                "skip": skip
            }
        
        logger.info(f"📋 Fetching requests - limit: {limit}, skip: {skip}, status: {status}")
        
        # Get requests based on status filter
        if status:
            requests = mongodb_service.get_customer_requests_by_status(status, limit)
        else:
            requests = mongodb_service.get_all_customer_requests(limit, skip)
        
        # Get total count
        total_count = mongodb_service.get_customer_requests_count()
        
        # Ensure requests is a list
        if not isinstance(requests, list):
            logger.warning(f"Requests is not a list: {type(requests)}")
            requests = []
        
        # Log sample request structure for debugging
        if requests:
            sample_request = requests[0]
            logger.info(f"📋 Sample request structure: {list(sample_request.keys())}")
            logger.info(f"📋 Sample service_type type: {type(sample_request.get('service_type', 'N/A'))}")
        
        logger.info(f"📋 Retrieved {len(requests)} customer requests (limit: {limit}, skip: {skip})")
        
        return {
            "success": True,
            "requests": requests,
            "total_count": total_count,
            "returned_count": len(requests),
            "limit": limit,
            "skip": skip,
            "status_filter": status,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Error retrieving customer requests: {str(e)}")
        import traceback
        logger.error(f"❌ Full traceback: {traceback.format_exc()}")
        return {
            "error": f"Failed to retrieve customer requests: {str(e)}",
            "requests": [],
            "total_count": 0,
            "limit": limit,
            "skip": skip
        }

@app.get("/api/test-schema")
async def test_schema():
    """Test endpoint to verify the new schema is working."""
    try:
        if not mongodb_service:
            return {"error": "MongoDB service not available"}
        
        # Get one request to test schema
        requests = mongodb_service.get_all_customer_requests(limit=1, skip=0)
        
        if not requests:
            return {
                "message": "No requests found in database",
                "schema_test": "No data to test"
            }
        
        sample_request = requests[0]
        
        # Check if it has the new schema fields
        has_new_fields = all(field in sample_request for field in [
            'created_by', 'source', 'auto_approved', 'truck_company_name'
        ])
        
        # Check service_type format
        service_type = sample_request.get('service_type', [])
        is_new_service_format = (
            isinstance(service_type, list) and 
            len(service_type) > 0 and 
            isinstance(service_type[0], dict) and 
            'name' in service_type[0] and 
            'service_status' in service_type[0]
        )
        
        return {
            "message": "Schema test completed",
            "sample_request_id": sample_request.get('_id'),
            "has_new_fields": has_new_fields,
            "is_new_service_format": is_new_service_format,
            "service_type_sample": service_type[:2] if service_type else [],
            "all_fields": list(sample_request.keys()),
            "schema_version": "new" if has_new_fields and is_new_service_format else "old"
        }
        
    except Exception as e:
        logger.error(f"❌ Schema test error: {str(e)}")
        return {"error": f"Schema test failed: {str(e)}"}

@app.get("/api/requests/count")
async def get_customer_requests_count():
    """
    Get the total count of customer requests.
    
    Returns:
        JSON response with total count
    """
    try:
        if not mongodb_service:
            return {
                "error": "MongoDB service not available",
                "total_count": 0
            }
        
        total_count = mongodb_service.get_customer_requests_count()
        
        logger.info(f"📊 Total customer requests count: {total_count}")
        
        return {
            "success": True,
            "total_count": total_count,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Error getting customer requests count: {str(e)}")
        return {
            "error": f"Failed to get count: {str(e)}",
            "total_count": 0
        }

@app.get("/api/requests/status/{status}")
async def get_customer_requests_by_status(status: str, limit: int = 100):
    """
    Get customer requests filtered by status.
    
    Args:
        status: Status to filter by (e.g., "Requested", "In Progress", "Completed")
        limit: Maximum number of requests to return (default: 100)
    
    Returns:
        JSON response with filtered customer requests
    """
    try:
        if not mongodb_service:
            return {
                "error": "MongoDB service not available",
                "requests": [],
                "status": status
            }
        
        requests = mongodb_service.get_customer_requests_by_status(status, limit)
        
        logger.info(f"📋 Retrieved {len(requests)} customer requests with status '{status}'")
        
        return {
            "success": True,
            "requests": requests,
            "status": status,
            "returned_count": len(requests),
            "limit": limit,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Error retrieving customer requests by status: {str(e)}")
        return {
            "error": f"Failed to retrieve requests by status: {str(e)}",
            "requests": [],
            "status": status
        }

@app.post("/api/tts")
async def text_to_speech(request: TTSRequest):
    """
    Convert text to speech using EdgeTTS with en-CA-LiamNeural voice.
    
    Args:
        request: TTSRequest containing text and voice parameters
    
    Returns:
        Audio file (MP3) as binary response
        
    Raises:
        HTTPException: If TTS conversion fails
    """
    try:
        if not request.text or not request.text.strip():
            raise HTTPException(status_code=400, detail="Text cannot be empty")
        
        # Limit text length to prevent very long audio files
        if len(request.text) > 5000:
            request.text = request.text[:5000] + "..."
            logger.warning(f"Text truncated to 5000 characters for TTS")
        
        logger.info(f"🎤 TTS request received: '{request.text[:50]}...' with voice: {request.voice}")
        logger.info(f"🔍 DEBUG: Current TTS service voice: {tts_service.voice}")
        logger.info(f"🔍 DEBUG: Request voice: {request.voice}")
        
        # Update TTS service voice if different from current
        if tts_service.voice != request.voice:
            logger.info(f"🔄 Voice mismatch detected! Updating TTS service voice from '{tts_service.voice}' to '{request.voice}'")
            tts_service.set_voice(request.voice)
        else:
            logger.info(f"✅ Voice already matches: {request.voice}")
        
        # Update TTS service settings if different from defaults
        if request.rate != "+20%" or request.pitch != "+0Hz" or request.volume != "+0%":
            tts_service.set_voice_settings(request.rate, request.pitch, request.volume)
        
        # Generate audio using fast TTS for quicker response
        audio_data = await tts_service.fast_text_to_speech(request.text)
        
        logger.success(f"✅ TTS conversion completed: {len(audio_data)} bytes")
        
        # Return audio file as binary response
        return Response(
            content=audio_data,
            media_type="audio/mpeg",
            headers={
                "Content-Disposition": "attachment; filename=speech.mp3",
                "Content-Length": str(len(audio_data))
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ TTS conversion failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"TTS conversion failed: {str(e)}")

@app.post("/api/tts/fast")
async def fast_text_to_speech(request: TTSRequest):
    """
    Fast text-to-speech conversion optimized for quick response.
    Uses shorter text limits and faster processing for immediate playback.
    
    Args:
        request: TTSRequest containing text and voice parameters
    
    Returns:
        Audio file (MP3) as binary response
        
    Raises:
        HTTPException: If TTS conversion fails
    """
    try:
        if not request.text or not request.text.strip():
            raise HTTPException(status_code=400, detail="Text cannot be empty")
        
        # Use shorter text limit for faster processing
        if len(request.text) > 1000:
            request.text = request.text[:1000] + "..."
            logger.warning(f"Text truncated to 1000 characters for fast TTS")
        
        logger.info(f"⚡ Fast TTS request received: '{request.text[:30]}...' with voice: {request.voice}")
        logger.info(f"🔍 DEBUG: Current TTS service voice: {tts_service.voice}")
        logger.info(f"🔍 DEBUG: Request voice: {request.voice}")
        
        # Update TTS service voice if different from current
        if tts_service.voice != request.voice:
            logger.info(f"🔄 Voice mismatch detected! Updating TTS service voice from '{tts_service.voice}' to '{request.voice}'")
            tts_service.set_voice(request.voice)
        else:
            logger.info(f"✅ Voice already matches: {request.voice}")
        
        # Generate audio using fast TTS method
        audio_data = await tts_service.fast_text_to_speech(request.text)
        
        logger.success(f"⚡ Fast TTS conversion completed: {len(audio_data)} bytes")
        
        # Return audio file as binary response
        return Response(
            content=audio_data,
            media_type="audio/mpeg",
            headers={
                "Content-Disposition": "attachment; filename=fast_speech.mp3",
                "Content-Length": str(len(audio_data))
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Fast TTS conversion failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Fast TTS conversion failed: {str(e)}")

@app.get("/api/supported-languages")
async def get_supported_languages():
    """Get list of supported languages."""
    return {
        "supported_languages": [
            {"code": "en-US", "name": "English", "region": "United States"},
            {"code": "en-GB", "name": "English", "region": "United Kingdom"},
            {"code": "hi-IN", "name": "Hindi", "region": "India"},
            {"code": "pa-IN", "name": "Punjabi", "region": "India"},
            {"code": "ru-RU", "name": "Russian", "region": "Russia"}
        ],
        "default_language": "en-US"
    }

@app.get("/api/supported-voices")
async def get_supported_voices():
    """Get list of supported voices."""
    return {
        "supported_voices": [
            {"id": "ash", "description": "Male voice - Calm and steady (OPTIMIZED)"},
            {"id": "onyx", "description": "Deep male voice - Helpful and friendly tone"},
            {"id": "echo", "description": "Male voice - Clear and professional"},
            {"id": "fable", "description": "Male voice with storytelling quality"},
            {"id": "alloy", "description": "Neutral voice - Balanced and versatile"},
            {"id": "nova", "description": "Female voice - Warm and approachable"},
            {"id": "shimmer", "description": "Female voice - Soft and gentle"},
            {"id": "coral", "description": "Female voice - Bright and energetic"},
            {"id": "sage", "description": "Male voice - Wise and authoritative"}
        ],
        "default_voice": "alloy"
    }

@app.get("/api/tts/voices")
async def get_available_voices():
    """
    Get list of available TTS voices.
    
    Returns:
        JSON response with available voices
    """
    try:
        voices = tts_service.get_available_voices()
        voice_info = tts_service.get_voice_info()
        
        logger.info(f"📋 Retrieved {len(voices)} available voices")
        
        return {
            "success": True,
            "current_voice": voice_info,
            "available_voices": voices[:20],  # Limit to first 20 for readability
            "total_voices": len(voices),
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Error getting available voices: {str(e)}")
        return {
            "error": f"Failed to get voices: {str(e)}",
            "available_voices": [],
            "total_voices": 0
        }

@app.websocket("/ws/regular")
async def regular_chatbot_websocket(websocket: WebSocket):
    """WebSocket endpoint for regular chatbot."""
    client_ip = websocket.client.host if websocket.client else "unknown"
    logger.info(f"🔌 New WebSocket connection from {client_ip} to /ws/regular")
    
    await websocket.accept()
    logger.info(f"✅ WebSocket connection accepted from {client_ip}")
    
    if not chat_service:
        logger.error("❌ Chat service not available, closing connection")
        await websocket.close(code=1011, reason="Chat service not available")
        return
    
    try:
        # Create session for regular chatbot
        session_id = await chat_service.create_session("regular")
        logger.info(f"🆔 Created session {session_id} for regular chatbot")
        
        # Send welcome message
        welcome_msg = {
            "type": "welcome",
            "message": "Welcome to AURA! How can I help you today?",
            "chatbot_type": "regular",
            "session_id": session_id
        }
        await websocket.send_text(json.dumps(welcome_msg))
        logger.info(f"📤 Sent welcome message to session {session_id}")
        
        # Store welcome message in memory until MongoDB session is created
        if chat_service:
            await chat_service.store_welcome_message(session_id, "general_chatbot", "Welcome to AURA! How can I help you today?")
        
        # Start keep-alive task
        keep_alive_task = asyncio.create_task(keep_alive_ping(websocket))
        
        try:
            while True:
                try:
                    # Receive message with extended timeout
                    data = await asyncio.wait_for(websocket.receive_text(), timeout=600.0)  # 10 minutes timeout
                    try:
                        message_data = json.loads(data)
                        logger.info(f"🔍 DEBUG: Raw WebSocket data received: {data}")
                        logger.info(f"🔍 DEBUG: Parsed WebSocket message: {message_data}")
                        logger.info(f"🔍 DEBUG: Message type: {message_data.get('type')}")
                        logger.info(f"🔍 DEBUG: Message voice field: {message_data.get('voice')}")
                    except json.JSONDecodeError as e:
                        logger.warning(f"Invalid JSON received from client: {str(e)}")
                        error_msg = {
                            "type": "error",
                            "message": "Invalid message format. Please send valid JSON.",
                            "chatbot_type": "regular",
                            "session_id": session_id
                        }
                        await websocket.send_text(json.dumps(error_msg))
                        continue
                    
                    if message_data.get("type") == "chat":
                        user_message = message_data.get("message", "")
                        input_language = message_data.get("input_language", "en-US")
                        voice = message_data.get("voice", "ash")  # Changed default from alloy to ash
                        
                        logger.info(f"📨 Received message from session {session_id}: '{user_message[:50]}...'")
                        logger.info(f"🌐 Language: {input_language}, 🎤 Voice: {voice}")
                        logger.info(f"🔍 DEBUG: WebSocket voice extraction - Raw voice: {message_data.get('voice')}, Final voice: {voice}")
                        logger.info(f"🔍 DEBUG: Full WebSocket message data: {message_data}")
                        logger.info(f"🔍 DEBUG: Available keys in message_data: {list(message_data.keys())}")
                        logger.info(f"🔍 DEBUG: Voice field exists: {'voice' in message_data}")
                        logger.info(f"🔍 DEBUG: Voice field value: {message_data.get('voice', 'NOT_PROVIDED')}")
                        
                        try:
                            # Get response from regular chatbot with language/voice context
                            response = await chat_service.get_regular_response(
                                user_message, 
                                session_id,
                                input_language=input_language,
                                voice=voice
                            )
                            logger.info(f"🤖 Generated response for session {session_id}: '{response['response'][:50]}...'")
                            
                            # Send response
                            response_msg = {
                                "type": "response",
                                "message": response["response"],
                                "chatbot_type": "regular",
                                "session_id": session_id,
                                "redirect": response.get("redirect", False)
                            }
                            await websocket.send_text(json.dumps(response_msg))
                            logger.info(f"📤 Sent response to session {session_id}")
                            
                            # Handle redirection suggestion
                            if response.get("redirect"):
                                redirect_msg = {
                                    "type": "redirect",
                                    "message": "This request should be handled by the modify chatbot. Please use /ws/modify endpoint.",
                                    "chatbot_type": "modify",
                                    "session_id": session_id
                                }
                                await websocket.send_text(json.dumps(redirect_msg))
                                
                        except Exception as e:
                            logger.error(f"Error processing regular chatbot message: {str(e)}")
                            error_msg = {
                                "type": "error",
                                "message": f"Sorry, I encountered an error: {str(e)}",
                                "chatbot_type": "regular",
                                "session_id": session_id
                            }
                            await websocket.send_text(json.dumps(error_msg))
                    
                    elif message_data.get("type") == "ping":
                        # Respond to ping with pong
                        pong_msg = {"type": "pong", "timestamp": message_data.get("timestamp")}
                        await websocket.send_text(json.dumps(pong_msg))
                        
                except asyncio.TimeoutError:
                    # Just continue waiting - keep-alive ping will handle connection
                    continue
                    
        finally:
            # Cancel keep-alive task
            keep_alive_task.cancel()
            try:
                await keep_alive_task
            except asyncio.CancelledError:
                pass
                
    except WebSocketDisconnect:
        # End the chat session
        logger.info(f"🔌 WebSocket disconnected for session {session_id}")
        if chat_service:
            await chat_service.end_session(session_id)
    except Exception as e:
        logger.error(f"❌ Regular chatbot WebSocket error: {str(e)}")
        # End the chat session on error
        if chat_service:
            await chat_service.end_session(session_id)
        try:
            await websocket.close(code=1011, reason=f"Server error: {str(e)}")
        except Exception:
            # WebSocket already closed, ignore
            pass

@app.websocket("/ws/modify")
async def modify_chatbot_websocket(websocket: WebSocket):
    """WebSocket endpoint for modify chatbot."""
    client_ip = websocket.client.host if websocket.client else "unknown"
    logger.info(f"🔌 New WebSocket connection from {client_ip} to /ws/modify")
    
    await websocket.accept()
    logger.info(f"✅ WebSocket connection accepted from {client_ip}")
    
    if not chat_service:
        logger.error("❌ Chat service not available, closing connection")
        await websocket.close(code=1011, reason="Chat service not available")
        return
    
    try:
        # Create session for modify chatbot
        session_id = await chat_service.create_session("modify")
        
        # Send welcome message
        welcome_msg = {
            "type": "welcome",
            "message": "Welcome to AURA Modify Chatbot! I'll help you update your existing requests.",
            "chatbot_type": "modify",
            "session_id": session_id
        }
        await websocket.send_text(json.dumps(welcome_msg))
        
        # Store welcome message in memory until MongoDB session is created
        if chat_service:
            await chat_service.store_welcome_message(session_id, "modify_chatbot", "Welcome to AURA Modify Chatbot! I'll help you update your existing requests.")
        
        # Start keep-alive task
        keep_alive_task = asyncio.create_task(keep_alive_ping(websocket))
        
        try:
            while True:
                try:
                    # Receive message with extended timeout
                    data = await asyncio.wait_for(websocket.receive_text(), timeout=600.0)  # 10 minutes timeout
                    try:
                        message_data = json.loads(data)
                        logger.info(f"🔍 DEBUG: Raw WebSocket data received: {data}")
                        logger.info(f"🔍 DEBUG: Parsed WebSocket message: {message_data}")
                        logger.info(f"🔍 DEBUG: Message type: {message_data.get('type')}")
                        logger.info(f"🔍 DEBUG: Message voice field: {message_data.get('voice')}")
                    except json.JSONDecodeError as e:
                        logger.warning(f"Invalid JSON received from client: {str(e)}")
                        error_msg = {
                            "type": "error",
                            "message": "Invalid message format. Please send valid JSON.",
                            "chatbot_type": "modify",
                            "session_id": session_id
                        }
                        await websocket.send_text(json.dumps(error_msg))
                        continue
                    
                    if message_data.get("type") == "chat":
                        user_message = message_data.get("message", "")
                        input_language = message_data.get("input_language", "en-US")
                        voice = message_data.get("voice", "ash")  # Changed default from alloy to ash
                        
                        logger.info(f"📨 Received message from session {session_id}: '{user_message[:50]}...'")
                        logger.info(f"🌐 Language: {input_language}, 🎤 Voice: {voice}")
                        logger.info(f"🔍 DEBUG: WebSocket voice extraction - Raw voice: {message_data.get('voice')}, Final voice: {voice}")
                        logger.info(f"🔍 DEBUG: Full WebSocket message data: {message_data}")
                        logger.info(f"🔍 DEBUG: Available keys in message_data: {list(message_data.keys())}")
                        logger.info(f"🔍 DEBUG: Voice field exists: {'voice' in message_data}")
                        logger.info(f"🔍 DEBUG: Voice field value: {message_data.get('voice', 'NOT_PROVIDED')}")
                        
                        try:
                            # Get response from modify chatbot with language/voice context
                            response = await chat_service.get_modify_response(
                                user_message, 
                                session_id,
                                input_language=input_language,
                                voice=voice
                            )
                            
                            # Send response
                            response_msg = {
                                "type": "response",
                                "message": response["response"],
                                "chatbot_type": "modify",
                                "session_id": session_id,
                                "redirect": response.get("redirect", False)
                            }
                            await websocket.send_text(json.dumps(response_msg))
                            
                            # Handle redirection suggestion
                            if response.get("redirect"):
                                redirect_msg = {
                                    "type": "redirect",
                                    "message": "This request should be handled by the regular chatbot. Please use /ws/regular endpoint.",
                                    "chatbot_type": "regular",
                                    "session_id": session_id
                                }
                                await websocket.send_text(json.dumps(redirect_msg))
                                
                        except Exception as e:
                            logger.error(f"Error processing modify chatbot message: {str(e)}")
                            error_msg = {
                                "type": "error",
                                "message": f"Sorry, I encountered an error: {str(e)}",
                                "chatbot_type": "modify",
                                "session_id": session_id
                            }
                            await websocket.send_text(json.dumps(error_msg))
                    
                    elif message_data.get("type") == "ping":
                        # Respond to ping with pong
                        pong_msg = {"type": "pong", "timestamp": message_data.get("timestamp")}
                        await websocket.send_text(json.dumps(pong_msg))
                        
                except asyncio.TimeoutError:
                    # Just continue waiting - keep-alive ping will handle connection
                    continue
                    
        finally:
            # Cancel keep-alive task
            keep_alive_task.cancel()
            try:
                await keep_alive_task
            except asyncio.CancelledError:
                pass
                
    except WebSocketDisconnect:
        # End the chat session
        logger.info(f"🔌 WebSocket disconnected for session {session_id}")
        if chat_service:
            await chat_service.end_session(session_id)
    except Exception as e:
        logger.error(f"❌ Modify chatbot WebSocket error: {str(e)}")
        # End the chat session on error
        if chat_service:
            await chat_service.end_session(session_id)
        try:
            await websocket.close(code=1011, reason=f"Server error: {str(e)}")
        except Exception:
            # WebSocket already closed, ignore
            pass

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=4000)
