# AURA Backend Integration Guide for Frontend Team

## Overview
This guide explains the new backend implementation for language-aware responses and dynamic TTS voice integration. The backend now supports multilingual conversations and uses the exact voice preferences sent from the frontend.

## New Features Implemented

### 1. Language-Aware Responses
- Chatbots now respond in the same language as the user's input
- Support for 5 languages: English (US/UK), Hindi, Punjabi, Russian
- Dynamic language switching during conversations

### 2. Dynamic TTS Voice Integration
- TTS service uses the exact voice sent from frontend
- Real-time voice switching for each request
- Support for 9 OpenAI voices (male, female, neutral)

## Updated WebSocket Message Structure

### Frontend to Backend Message Format
```json
{
  "type": "chat",
  "message": "Hello, I need help with my truck",
  "input_language": "en-US",
  "voice": "nova",
  "chatbot_type": "regular",
  "session_id": "session_12345"
}
```

### New Fields Added
- `input_language` (string, optional): User's language preference
- `voice` (string, optional): User's voice preference for TTS

### Backend Response Format
```json
{
  "type": "response",
  "message": "Hello! I'll be happy to help you with your truck. What's your name?",
  "chatbot_type": "regular",
  "session_id": "session_12345",
  "redirect": false
}
```

## Supported Languages

| Language Code | Language Name | Region | Example |
|---------------|---------------|---------|---------|
| `en-US` | English | United States | "Hello, I need help with my truck" |
| `en-GB` | English | United Kingdom | "Hello, I need help with my lorry" |
| `hi-IN` | Hindi | India | "नमस्ते, मुझे अपनी ट्रक की मदद चाहिए" |
| `pa-IN` | Punjabi | India | "ਸਤ ਸ੍ਰੀ ਅਕਾਲ, ਮੈਨੂੰ ਆਪਣੇ ਟਰੱਕ ਦੀ ਮਦਦ ਚਾਹੀਦੀ ਹੈ" |
| `ru-RU` | Russian | Russia | "Привет, мне нужна помощь с моим грузовиком" |

## Supported Voices

| Voice ID | Type | Description |
|----------|------|-------------|
| `ash` | Male | Calm and steady (OPTIMIZED) |
| `onyx` | Male | Deep male voice - Helpful and friendly tone |
| `echo` | Male | Clear and professional |
| `fable` | Male | Male voice with storytelling quality |
| `alloy` | Neutral | Balanced and versatile |
| `nova` | Female | Warm and approachable |
| `shimmer` | Female | Soft and gentle |
| `coral` | Female | Bright and energetic |
| `sage` | Male | Wise and authoritative |

## New API Endpoints

### 1. Get Supported Languages
**Endpoint:** `GET /api/supported-languages`

**Response:**
```json
{
  "supported_languages": [
    {"code": "en-US", "name": "English", "region": "United States"},
    {"code": "en-GB", "name": "English", "region": "United Kingdom"},
    {"code": "hi-IN", "name": "Hindi", "region": "India"},
    {"code": "pa-IN", "name": "Punjabi", "region": "India"},
    {"code": "ru-RU", "name": "Russian", "region": "Russia"}
  ],
  "default_language": "en-US"
}
```

### 2. Get Supported Voices
**Endpoint:** `GET /api/supported-voices`

**Response:**
```json
{
  "supported_voices": [
    {"id": "ash", "description": "Male voice - Calm and steady (OPTIMIZED)"},
    {"id": "onyx", "description": "Deep male voice - Helpful and friendly tone"},
    {"id": "echo", "description": "Male voice - Clear and professional"},
    {"id": "fable", "description": "Male voice with storytelling quality"},
    {"id": "alloy", "description": "Neutral voice - Balanced and versatile"},
    {"id": "nova", "description": "Female voice - Warm and approachable"},
    {"id": "shimmer", "description": "Female voice - Soft and gentle"},
    {"id": "coral", "description": "Female voice - Bright and energetic"},
    {"id": "sage", "description": "Male voice - Wise and authoritative"}
  ],
  "default_voice": "alloy"
}
```

## Updated TTS Endpoints

### 1. Text-to-Speech
**Endpoint:** `POST /api/tts`

**Request Body:**
```json
{
  "text": "Hello, I need help with my truck",
  "voice": "nova"
}
```

**Response:** Audio file (MP3) as binary response

### 2. Fast Text-to-Speech
**Endpoint:** `POST /api/tts/fast`

**Request Body:**
```json
{
  "text": "Hello, I need help with my truck",
  "voice": "nova"
}
```

**Response:** Audio file (MP3) as binary response (optimized for quick response)

## WebSocket Integration

### Regular Chatbot WebSocket
**URL:** `wss://auraai-ul12.onrender.com/ws/regular`

### Modify Chatbot WebSocket
**URL:** `wss://auraai-ul12.onrender.com/ws/modify`

### Message Flow Example

#### 1. User sends message in Hindi with female voice:
```json
{
  "type": "chat",
  "message": "मुझे अपनी ट्रक की मदद चाहिए",
  "input_language": "hi-IN",
  "voice": "nova",
  "chatbot_type": "regular",
  "session_id": "session_12345"
}
```

#### 2. Backend responds in Hindi:
```json
{
  "type": "response",
  "message": "नमस्ते! मैं आपकी ट्रक की मदद करने में खुशी होगी। आपका नाम क्या है?",
  "chatbot_type": "regular",
  "session_id": "session_12345",
  "redirect": false
}
```

#### 3. Frontend can then call TTS with nova voice:
```json
POST /api/tts/fast
{
  "text": "नमस्ते! मैं आपकी ट्रक की मदद करने में खुशी होगी। आपका नाम क्या है?",
  "voice": "nova"
}
```

## Implementation Requirements for Frontend

### 1. WebSocket Message Updates
Update your WebSocket message structure to include:
```typescript
interface WebSocketMessage {
  type: 'chat' | 'welcome' | 'response' | 'redirect' | 'ping' | 'pong' | 'error';
  message?: string;
  chatbot_type?: ChatbotType;
  session_id?: string;
  redirect?: boolean;
  input_language?: string;  // NEW FIELD
  voice?: string;          // NEW FIELD
}
```

### 2. Language Selection
- Implement language selection UI with supported languages
- Store user's language preference
- Send `input_language` with every chat message

### 3. Voice Selection
- Implement voice selection UI with supported voices
- Store user's voice preference
- Send `voice` with every chat message
- Use the same voice for TTS requests

### 4. TTS Integration
- Update TTS requests to include the `voice` field
- Use the same voice that was sent in the WebSocket message
- Handle both `/api/tts` and `/api/tts/fast` endpoints

## Backward Compatibility

### Default Values
- If `input_language` is not provided: defaults to `"en-US"`
- If `voice` is not provided: defaults to `"alloy"`
- Existing clients without these fields will continue to work

### Validation
- Invalid language codes fallback to `"en-US"`
- Invalid voice IDs fallback to `"alloy"`
- No breaking changes to existing functionality

## Error Handling

### Language Validation
```json
// Invalid language sent
{
  "input_language": "invalid-lang"
}
// Backend automatically uses "en-US"
```

### Voice Validation
```json
// Invalid voice sent
{
  "voice": "invalid-voice"
}
// Backend automatically uses "alloy"
```

## Testing Checklist

### Frontend Testing
- [ ] Language selection persists across page reloads
- [ ] Voice selection persists across page reloads
- [ ] WebSocket messages include language and voice fields
- [ ] Settings modal shows correct selected values
- [ ] Toast notifications work for language/voice changes
- [ ] TTS uses the selected voice
- [ ] Chatbot responds in selected language

### Backend Testing
- [ ] WebSocket handler receives new fields correctly
- [ ] Language codes are validated
- [ ] Voice IDs are validated
- [ ] Response generation uses language context
- [ ] TTS uses the correct voice
- [ ] Session management maintains preferences

## Example Implementation

### JavaScript/TypeScript Example
```typescript
// WebSocket message with language and voice
const message = {
  type: 'chat',
  message: userInput,
  input_language: selectedLanguage, // e.g., 'hi-IN'
  voice: selectedVoice,             // e.g., 'nova'
  chatbot_type: 'regular',
  session_id: sessionId
};

websocket.send(JSON.stringify(message));

// TTS request with same voice
const ttsResponse = await fetch('/api/tts/fast', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    text: chatbotResponse,
    voice: selectedVoice // Same voice as WebSocket message
  })
});
```

## Migration Notes

### For Existing Frontend Code
1. Add `input_language` and `voice` fields to WebSocket messages
2. Update TTS requests to include voice parameter
3. Implement language and voice selection UI
4. Test with different language/voice combinations

### Database Schema Updates
The backend automatically stores language and voice preferences in MongoDB:
```json
{
  "session_id": "session_12345",
  "input_language": "hi-IN",
  "voice": "nova",
  "messages": [
    {
      "user_message": "मुझे अपनी ट्रक की मदद चाहिए",
      "assistant_message": "नमस्ते! मैं आपकी ट्रक की मदद करने में खुशी होगी।",
      "input_language": "hi-IN",
      "voice": "nova",
      "timestamp": "2024-01-01T12:00:00Z"
    }
  ]
}
```

## Support and Questions

For any questions about this integration:
1. Check the backend code in the respective service files
2. Test with the provided examples above
3. Ensure backward compatibility with existing clients
4. Use the API endpoints to get supported languages and voices

## Version Information

- **Backend Version**: 2.0.0
- **Integration Date**: January 2024
- **Breaking Changes**: None (backward compatible)
- **New Features**: Language-aware responses and dynamic TTS voice integration

---

**Note**: This implementation maintains full backward compatibility. Existing frontend code will continue to work without modifications, but will use default English responses and alloy voice.
