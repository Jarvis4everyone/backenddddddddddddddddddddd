# AURA Backend API - WebSocket Only

A FastAPI-based backend system for AURA chatbot with WebSocket-only communication, MongoDB integration, and comprehensive chat logging.

## Features

- 🚀 **FastAPI Backend**: Modern, fast web framework with WebSocket support
- 🤖 **Dual Chatbot System**: Separate regular and modify chatbots for different use cases
- 📊 **MongoDB Integration**: Persistent storage for chat sessions and learning data
- 📝 **Comprehensive Chat Logging**: All conversations saved with timestamps and classification
- 🔄 **Learning Data Integration**: FAISS-based vector search for knowledge base queries
- 📡 **WebSocket-Only Communication**: Real-time bidirectional communication
- 🏗️ **Modular Architecture**: Clean separation of concerns with dedicated services

## Project Structure

```
Aura Backend/
├── app.py                      # Main FastAPI application
├── run.py                      # Server startup script
├── config.py                   # Configuration management
├── requirements.txt            # Python dependencies
├── Chatbot/                    # Regular chatbot module
│   ├── __init__.py
│   ├── Chatbot.py             # Main chatbot implementation
│   ├── Prompt.py              # System prompts
│   └── MongoDBService.py      # MongoDB operations
├── Modify/                     # Modify chatbot module
│   ├── __init__.py
│   ├── Chatbot.py             # Modify chatbot implementation
│   └── Prompt.py              # Modify-specific prompts
├── Data/                       # Learning data management
│   ├── LearningManager.py     # FAISS-based learning system
│   └── learning_data/         # Downloaded learning documents
├── services/                   # Backend services
│   ├── __init__.py
│   ├── chat_service.py        # Chat management service
│   ├── learning_service.py    # Learning data service
│   └── chat_logging_service.py # MongoDB chat logging
├── models/                     # Pydantic models
│   └── chat_models.py         # WebSocket message models
├── regular_chatbot_websocket_test.py     # WebSocket test client for regular chatbot
├── modify_chatbot_websocket_test.py     # WebSocket test client for modify chatbot
└── README.md                  # This file
```

## Setup Instructions

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Environment Configuration

Create a `.env` file in the project root directory:

```env
# OpenAI API Configuration
OPENAI_API_KEY=sk-your-openai-api-key-here

# MongoDB Configuration
MongoDB_URL=mongodb://localhost:27017/aura

# Server Configuration
HOST=0.0.0.0
PORT=4000
```

### 3. Start the Server

```bash
python run.py
```

The server will start on `http://localhost:4000` with:
- 📖 API Documentation: `http://localhost:4000/docs`
- ❤️ Health Check: `http://localhost:4000/health`

## API Endpoints

### WebSocket Connections

- `WS /ws/regular` - Regular chatbot WebSocket endpoint
- `WS /ws/modify` - Modify chatbot WebSocket endpoint

### REST API Endpoints

- `GET /` - API information and available endpoints
- `GET /health` - Server health check
- `GET /api/requests` - Get all customer requests with pagination
- `GET /api/requests/count` - Get total count of customer requests
- `GET /api/requests/status/{status}` - Get requests filtered by status

### Customer Requests API

#### Get All Requests
```bash
GET /api/requests?limit=100&skip=0&status=Requested
```

**Response:**
```json
{
  "success": true,
  "requests": [
    {
      "_id": "64f8a1b2c3d4e5f6a7b8c9d0",
      "customer_name": "John Doe",
      "contact_number": "1234567890",
      "truck_id": "TRK-001",
      "truck_company": "Mercedes",
      "service_type": ["Brake Pad Replacement", "Oil Change"],
      "priority": "urgent",
      "notes": "Need urgent service",
      "status": "Requested",
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T10:30:00Z"
    }
  ],
  "total_count": 25,
  "returned_count": 1,
  "limit": 100,
  "skip": 0,
  "status_filter": "Requested",
  "timestamp": "2024-01-15T10:35:00Z"
}
```

#### Get Request Count
```bash
GET /api/requests/count
```

**Response:**
```json
{
  "success": true,
  "total_count": 25,
  "timestamp": "2024-01-15T10:35:00Z"
}
```

#### Get Requests by Status
```bash
GET /api/requests/status/Requested?limit=50
```

**Response:**
```json
{
  "success": true,
  "requests": [...],
  "status": "Requested",
  "returned_count": 5,
  "limit": 50,
  "timestamp": "2024-01-15T10:35:00Z"
}
```

### Query Parameters

- `limit` (optional): Maximum number of requests to return (default: 100)
- `skip` (optional): Number of requests to skip for pagination (default: 0)
- `status` (optional): Filter by status (e.g., "Requested", "In Progress", "Completed")

## 🤖 Chatbot Usage Guide

### Understanding the Two Chatbots

The AURA system has **two specialized chatbots** designed for different purposes:

#### 1. **Regular Chatbot** (`/ws/regular`)
**Purpose**: Handle new service requests, general inquiries, and information requests.

**Best Use Cases**:
- New service bookings
- Pricing inquiries
- Service information requests
- General questions about services
- Scheduling new appointments

**Example Interactions**:
```
User: "I need brake pad replacement for my truck"
Bot: "I'll help you with brake pad replacement. Let me gather some information..."

User: "What are your truck wash prices?"
Bot: "We offer Basic Truck Wash for $50 and Deluxe Truck Wash for $120..."

User: "What services do you offer?"
Bot: "We provide comprehensive truck services including..."
```

#### 2. **Modify Chatbot** (`/ws/modify`)
**Purpose**: Handle updates to existing requests, modifications, and changes.

**Best Use Cases**:
- Updating contact information
- Changing appointment times
- Modifying service details
- Canceling requests
- Updating vehicle information

**Example Interactions**:
```
User: "My name is John, contact 1234567890"
Bot: "Hello John! Let me search for your existing request..."

User: "I want to change my appointment time"
Bot: "I'll help you update your appointment. What time works better?"

User: "Cancel my brake pad replacement request"
Bot: "I'll help you cancel that request. Let me find your booking..."
```

### 🎯 Frontend Integration Strategy

#### **Recommended Approach: Dual-Endpoint Design**

For the best user experience, implement **two separate chat interfaces**:

1. **Service Request Interface** → Connect to `/ws/regular`
2. **Modify Request Interface** → Connect to `/ws/modify`

#### **Alternative Approach: Smart Routing**

If you prefer a single chat interface, implement smart routing:

```javascript
// Determine which chatbot to use based on user intent
function determineChatbotType(userMessage) {
    const modifyKeywords = [
        'update', 'change', 'modify', 'cancel', 'edit',
        'my name is', 'contact', 'phone', 'appointment'
    ];
    
    const regularKeywords = [
        'need', 'want', 'book', 'schedule', 'price', 'cost',
        'service', 'wash', 'repair', 'maintenance'
    ];
    
    const message = userMessage.toLowerCase();
    
    if (modifyKeywords.some(keyword => message.includes(keyword))) {
        return 'modify';
    } else if (regularKeywords.some(keyword => message.includes(keyword))) {
        return 'regular';
    }
    
    // Default to regular for new requests
    return 'regular';
}
```

### 🔄 Chatbot Redirection System

Both chatbots can suggest redirection when appropriate:

#### **Regular → Modify Redirection**
When a user tries to modify something in the regular chatbot:
```json
{
    "type": "redirect",
    "message": "This request should be handled by the modify chatbot. Please use /ws/modify endpoint.",
    "chatbot_type": "modify",
    "session_id": "uuid-session-id"
}
```

#### **Modify → Regular Redirection**
When a user tries to make a new request in the modify chatbot:
```json
{
    "type": "redirect",
    "message": "This request should be handled by the regular chatbot. Please use /ws/regular endpoint.",
    "chatbot_type": "regular",
    "session_id": "uuid-session-id"
}
```

### 📱 Frontend Implementation Examples

#### **React/Next.js Example**

```jsx
import { useState, useEffect, useRef } from 'react';

function ChatInterface({ chatbotType = 'regular' }) {
    const [messages, setMessages] = useState([]);
    const [isConnected, setIsConnected] = useState(false);
    const wsRef = useRef(null);
    
    useEffect(() => {
        const endpoint = chatbotType === 'regular' ? '/ws/regular' : '/ws/modify';
        const ws = new WebSocket(`ws://localhost:4000${endpoint}`);
        
        ws.onopen = () => {
            setIsConnected(true);
        };
        
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            if (data.type === 'welcome') {
                setMessages([{
                    type: 'bot',
                    content: data.message,
                    timestamp: new Date()
                }]);
            } else if (data.type === 'response') {
                setMessages(prev => [...prev, {
                    type: 'bot',
                    content: data.message,
                    timestamp: new Date()
                }]);
                
                // Handle redirection
                if (data.redirect) {
                    // Show redirection message or switch chatbot
                    console.log('Redirection suggested:', data.message);
                }
            }
        };
        
        ws.onclose = () => {
            setIsConnected(false);
        };
        
        wsRef.current = ws;
        
        return () => ws.close();
    }, [chatbotType]);
    
    const sendMessage = (message) => {
        if (wsRef.current && isConnected) {
            wsRef.current.send(JSON.stringify({
                type: 'chat',
                message: message
            }));
            
            setMessages(prev => [...prev, {
                type: 'user',
                content: message,
                timestamp: new Date()
            }]);
        }
    };
    
    return (
        <div className="chat-interface">
            <div className="chat-header">
                <h3>{chatbotType === 'regular' ? 'Service Requests' : 'Modify Requests'}</h3>
                <span className={`status ${isConnected ? 'connected' : 'disconnected'}`}>
                    {isConnected ? 'Connected' : 'Disconnected'}
                </span>
            </div>
            
            <div className="messages">
                {messages.map((msg, index) => (
                    <div key={index} className={`message ${msg.type}`}>
                        {msg.content}
                    </div>
                ))}
            </div>
            
            <div className="input-area">
                <input 
                    type="text" 
                    placeholder={chatbotType === 'regular' 
                        ? "Ask about services or make a request..." 
                        : "Update your existing request..."
                    }
                    onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                            sendMessage(e.target.value);
                            e.target.value = '';
                        }
                    }}
                />
            </div>
        </div>
    );
}
```

#### **Vue.js Example**

```vue
<template>
  <div class="chat-container">
    <div class="chat-header">
      <h3>{{ chatbotType === 'regular' ? 'Service Requests' : 'Modify Requests' }}</h3>
      <span :class="['status', { connected: isConnected }]">
        {{ isConnected ? 'Connected' : 'Disconnected' }}
      </span>
    </div>
    
    <div class="messages">
      <div 
        v-for="(message, index) in messages" 
        :key="index" 
        :class="['message', message.type]"
      >
        {{ message.content }}
      </div>
    </div>
    
    <div class="input-area">
      <input 
        v-model="newMessage"
        :placeholder="chatbotType === 'regular' 
          ? 'Ask about services or make a request...' 
          : 'Update your existing request...'
        "
        @keyup.enter="sendMessage"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'ChatInterface',
  props: {
    chatbotType: {
      type: String,
      default: 'regular'
    }
  },
  data() {
    return {
      messages: [],
      isConnected: false,
      newMessage: '',
      ws: null
    }
  },
  mounted() {
    this.connectWebSocket();
  },
  beforeUnmount() {
    if (this.ws) {
      this.ws.close();
    }
  },
  methods: {
    connectWebSocket() {
      const endpoint = this.chatbotType === 'regular' ? '/ws/regular' : '/ws/modify';
      this.ws = new WebSocket(`ws://localhost:4000${endpoint}`);
      
      this.ws.onopen = () => {
        this.isConnected = true;
      };
      
      this.ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        if (data.type === 'welcome') {
          this.messages = [{
            type: 'bot',
            content: data.message,
            timestamp: new Date()
          }];
        } else if (data.type === 'response') {
          this.messages.push({
            type: 'bot',
            content: data.message,
            timestamp: new Date()
          });
        }
      };
      
      this.ws.onclose = () => {
        this.isConnected = false;
      };
    },
    
    sendMessage() {
      if (this.ws && this.isConnected && this.newMessage.trim()) {
        this.ws.send(JSON.stringify({
          type: 'chat',
          message: this.newMessage
        }));
        
        this.messages.push({
          type: 'user',
          content: this.newMessage,
          timestamp: new Date()
        });
        
        this.newMessage = '';
      }
    }
  }
}
</script>
```

### 🎨 UI/UX Best Practices

#### **1. Clear Visual Distinction**
- Use different colors for each chatbot interface
- Regular: Blue/Green theme (new requests)
- Modify: Orange/Yellow theme (updates)

#### **2. Contextual Placeholders**
```javascript
const placeholders = {
  regular: [
    "I need brake pad replacement",
    "What are your truck wash prices?",
    "Schedule an oil change"
  ],
  modify: [
    "My name is John, contact 1234567890",
    "Change my appointment time",
    "Update my service request"
  ]
};
```

#### **3. Smart Suggestions**
Show quick action buttons based on chatbot type:

**Regular Chatbot Suggestions**:
- "Book Service"
- "Check Prices"
- "Service Information"
- "Schedule Appointment"

**Modify Chatbot Suggestions**:
- "Update Contact"
- "Change Time"
- "Cancel Request"
- "Modify Details"

#### **4. Error Handling**
```javascript
const handleWebSocketError = (error) => {
  console.error('WebSocket error:', error);
  
  // Show user-friendly error message
  setMessages(prev => [...prev, {
    type: 'system',
    content: 'Connection lost. Please refresh to reconnect.',
    timestamp: new Date()
  }]);
  
  // Attempt reconnection
  setTimeout(() => {
    connectWebSocket();
  }, 3000);
};
```

### 🔧 Advanced Features

#### **1. Session Management**
```javascript
// Store session ID for continuity
const [sessionId, setSessionId] = useState(null);

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  
  if (data.session_id) {
    setSessionId(data.session_id);
    localStorage.setItem('aura_session_id', data.session_id);
  }
};
```

#### **2. Message History**
```javascript
// Load previous messages from localStorage
useEffect(() => {
  const savedMessages = localStorage.getItem('aura_messages');
  if (savedMessages) {
    setMessages(JSON.parse(savedMessages));
  }
}, []);

// Save messages to localStorage
useEffect(() => {
  localStorage.setItem('aura_messages', JSON.stringify(messages));
}, [messages]);
```

#### **3. Typing Indicators**
```javascript
const [isTyping, setIsTyping] = useState(false);

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  
  if (data.type === 'response') {
    setIsTyping(false);
    // Add message to chat
  }
};

// Show typing indicator when sending message
const sendMessage = (message) => {
  setIsTyping(true);
  ws.send(JSON.stringify({ type: 'chat', message }));
};
```

### 📊 Analytics and Monitoring

#### **Track User Interactions**
```javascript
const trackInteraction = (chatbotType, action, message) => {
  // Send analytics data
  analytics.track('chatbot_interaction', {
    chatbot_type: chatbotType,
    action: action,
    message_length: message.length,
    timestamp: new Date()
  });
};
```

#### **Monitor Connection Health**
```javascript
const [connectionHealth, setConnectionHealth] = useState('good');

// Ping server periodically
useEffect(() => {
  const pingInterval = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'ping' }));
    }
  }, 30000); // Every 30 seconds
  
  return () => clearInterval(pingInterval);
}, [ws]);
```

### 🚀 Production Considerations

#### **1. Environment Configuration**
```javascript
const getWebSocketUrl = () => {
  const isDevelopment = process.env.NODE_ENV === 'development';
  const baseUrl = isDevelopment ? 'ws://localhost:4000' : 'wss://your-domain.com';
  
  return baseUrl;
};
```

#### **2. Reconnection Strategy**
```javascript
const reconnectWebSocket = () => {
  let reconnectAttempts = 0;
  const maxAttempts = 5;
  
  const attemptReconnect = () => {
    if (reconnectAttempts < maxAttempts) {
      reconnectAttempts++;
      setTimeout(() => {
        connectWebSocket();
      }, Math.pow(2, reconnectAttempts) * 1000); // Exponential backoff
    }
  };
  
  return attemptReconnect;
};
```

#### **3. Error Boundaries**
```jsx
class ChatErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }
  
  componentDidCatch(error, errorInfo) {
    console.error('Chat error:', error, errorInfo);
  }
  
  render() {
    if (this.state.hasError) {
      return <div>Something went wrong with the chat. Please refresh.</div>;
    }
    
    return this.props.children;
  }
}
```

### 🎯 Best Practices for Using Both Chatbots

#### **1. User Flow Design**

**Recommended User Journey**:
```
1. User lands on homepage
2. Clear choice: "New Service Request" OR "Modify Existing Request"
3. Route to appropriate chatbot
4. Handle redirections gracefully
5. Provide easy switching between chatbots
```

#### **2. Navigation Strategy**

**Option A: Tab-Based Interface**
```jsx
function ChatApp() {
  const [activeTab, setActiveTab] = useState('regular');
  
  return (
    <div className="chat-app">
      <div className="tabs">
        <button 
          className={activeTab === 'regular' ? 'active' : ''}
          onClick={() => setActiveTab('regular')}
        >
          New Service Request
        </button>
        <button 
          className={activeTab === 'modify' ? 'active' : ''}
          onClick={() => setActiveTab('modify')}
        >
          Modify Request
        </button>
      </div>
      
      <ChatInterface chatbotType={activeTab} />
    </div>
  );
}
```

**Option B: Modal-Based Interface**
```jsx
function ServiceModal({ isOpen, onClose, chatbotType }) {
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ChatInterface chatbotType={chatbotType} />
    </Modal>
  );
}
```

#### **3. Smart Context Switching**

```javascript
const handleRedirection = (redirectData) => {
  if (redirectData.chatbot_type === 'modify') {
    // Switch to modify chatbot
    setActiveTab('modify');
    showNotification('Switching to modify chatbot for your request');
  } else if (redirectData.chatbot_type === 'regular') {
    // Switch to regular chatbot
    setActiveTab('regular');
    showNotification('Switching to service request chatbot');
  }
};
```

#### **4. User Education**

**Onboarding Tips**:
- Show tooltips explaining each chatbot's purpose
- Provide example messages for each chatbot
- Use progressive disclosure for advanced features

```jsx
const OnboardingTooltip = ({ chatbotType }) => (
  <div className="tooltip">
    <h4>{chatbotType === 'regular' ? 'New Service Requests' : 'Modify Requests'}</h4>
    <p>
      {chatbotType === 'regular' 
        ? 'Use this chatbot to book new services, check prices, or get information.'
        : 'Use this chatbot to update existing requests, change appointments, or modify details.'
      }
    </p>
    <div className="examples">
      <strong>Try saying:</strong>
      <ul>
        {chatbotType === 'regular' ? (
          <>
            <li>"I need brake pad replacement"</li>
            <li>"What are your truck wash prices?"</li>
            <li>"Schedule an oil change"</li>
          </>
        ) : (
          <>
            <li>"My name is John, contact 1234567890"</li>
            <li>"Change my appointment time"</li>
            <li>"Cancel my service request"</li>
          </>
        )}
      </ul>
    </div>
  </div>
);
```

#### **5. Performance Optimization**

**Connection Management**:
```javascript
const useWebSocketManager = () => {
  const [connections, setConnections] = useState({});
  
  const getConnection = (chatbotType) => {
    if (!connections[chatbotType]) {
      const endpoint = chatbotType === 'regular' ? '/ws/regular' : '/ws/modify';
      const ws = new WebSocket(`ws://localhost:4000${endpoint}`);
      
      setConnections(prev => ({
        ...prev,
        [chatbotType]: ws
      }));
    }
    
    return connections[chatbotType];
  };
  
  const closeConnection = (chatbotType) => {
    if (connections[chatbotType]) {
      connections[chatbotType].close();
      setConnections(prev => {
        const newConnections = { ...prev };
        delete newConnections[chatbotType];
        return newConnections;
      });
    }
  };
  
  return { getConnection, closeConnection };
};
```

#### **6. State Management**

**Redux/Zustand Example**:
```javascript
// Using Zustand for state management
import { create } from 'zustand';

const useChatStore = create((set, get) => ({
  activeChatbot: 'regular',
  messages: {
    regular: [],
    modify: []
  },
  sessions: {
    regular: null,
    modify: null
  },
  
  switchChatbot: (chatbotType) => {
    set({ activeChatbot: chatbotType });
  },
  
  addMessage: (chatbotType, message) => {
    set(state => ({
      messages: {
        ...state.messages,
        [chatbotType]: [...state.messages[chatbotType], message]
      }
    }));
  },
  
  setSession: (chatbotType, sessionId) => {
    set(state => ({
      sessions: {
        ...state.sessions,
        [chatbotType]: sessionId
      }
    }));
  }
}));
```

#### **7. Error Recovery**

**Graceful Degradation**:
```javascript
const ChatErrorHandler = ({ chatbotType, onRetry }) => {
  const [error, setError] = useState(null);
  
  const handleError = (error) => {
    setError(error);
    
    // Log error for debugging
    console.error(`Chatbot ${chatbotType} error:`, error);
    
    // Show user-friendly message
    showToast('Connection issue. Retrying...', 'warning');
    
    // Attempt recovery
    setTimeout(() => {
      onRetry();
      setError(null);
    }, 3000);
  };
  
  if (error) {
    return (
      <div className="error-state">
        <h3>Connection Issue</h3>
        <p>We're having trouble connecting to the {chatbotType} chatbot.</p>
        <button onClick={onRetry}>Retry Connection</button>
      </div>
    );
  }
  
  return null;
};
```

#### **8. Analytics Integration**

**Track User Behavior**:
```javascript
const useAnalytics = () => {
  const trackChatbotUsage = (chatbotType, action, data) => {
    analytics.track('chatbot_usage', {
      chatbot_type: chatbotType,
      action: action,
      timestamp: new Date(),
      ...data
    });
  };
  
  const trackRedirection = (fromChatbot, toChatbot, reason) => {
    analytics.track('chatbot_redirection', {
      from_chatbot: fromChatbot,
      to_chatbot: toChatbot,
      reason: reason,
      timestamp: new Date()
    });
  };
  
  return { trackChatbotUsage, trackRedirection };
};
```

## Testing the Chatbots

### Regular Chatbot Testing

For testing the regular chatbot (service requests, information, pricing):

```bash
python test_regular_chatbot.py
```

**Example Usage:**
```
👤 You: I need brake pad replacement for my truck
🤖 AURA Regular Chatbot: I'll help you with brake pad replacement...

👤 You: What are your truck wash prices?
🤖 AURA Regular Chatbot: Our truck wash services are available at two pricing levels...
```

### Modify Chatbot Testing

For testing the modify chatbot (updating existing requests):

```bash
python test_modify_chatbot.py
```

**Example Usage:**
```
👤 You: My name is John, contact 1234567890
🤖 AURA Modify Chatbot: Hello John! Let me search for your existing request...

👤 You: I want to change my appointment time
🤖 AURA Modify Chatbot: I'll help you update your appointment time...
```

### WebSocket Test Client Features

Both WebSocket test clients include:
- ✅ **Real-time Communication** - Instant message exchange
- 📊 **Automatic Chat Logging** - All conversations saved to MongoDB
- 🔄 **Session Management** - Unique session IDs for tracking
- ⏳ **Response Waiting** - Proper turn-based conversation flow
- 🛡️ **Error Handling** - Graceful handling of connection issues

## WebSocket Message Format

### Client to Server Messages

```json
{
  "type": "chat",
  "message": "I need brake pad replacement"
}
```

```json
{
  "type": "ping"
}
```

### Server to Client Messages

```json
{
  "type": "welcome",
  "message": "Welcome to AURA Regular Chatbot! How can I help you today?",
  "chatbot_type": "regular",
  "session_id": "uuid-session-id"
}
```

```json
{
  "type": "response",
  "message": "I'll help you with brake pad replacement...",
  "chatbot_type": "regular",
  "session_id": "uuid-session-id",
  "redirect": false
}
```

```json
{
  "type": "redirect",
  "message": "This request should be handled by the modify chatbot. Please use /ws/modify endpoint.",
  "chatbot_type": "modify",
  "session_id": "uuid-session-id"
}
```

```json
{
  "type": "pong"
}
```

## Chat Logging System

### MongoDB Structure

All chat sessions are saved to MongoDB in the `aura.chats` collection:

```json
{
  "_id": "session-uuid",
  "session_id": "session-uuid",
  "chatbot_type": "general_chatbot" | "modify_chatbot",
  "status": "active" | "ended",
  "created_at": "2024-01-01T12:00:00Z",
  "updated_at": "2024-01-01T12:05:00Z",
  "ended_at": "2024-01-01T12:10:00Z",
  "message_count": 5,
  "messages": [
    {
      "user_message": "I need brake pad replacement",
      "assistant_message": "I'll help you with brake pad replacement...",
      "chatbot_type": "general_chatbot",
      "timestamp": "2024-01-01T12:01:00Z"
    }
  ]
}
```

### Chat Classification

- **`general_chatbot`** - Regular service requests, information, pricing
- **`modify_chatbot`** - Updates to existing requests, modifications

## Learning Data Integration

The system automatically downloads learning data from MongoDB and creates a FAISS vector database for semantic search. This allows the chatbots to provide accurate, specific answers based on the knowledge base.

### Learning Data Sources

- Service pricing information
- Service descriptions and procedures
- Company policies and guidelines
- Frequently asked questions

## Architecture

### Services

- **`ChatService`** - Manages chatbot interactions and session state
- **`LearningService`** - Handles learning data and vector search
- **`ChatLoggingService`** - Manages MongoDB chat logging operations

### Models

- **`WebSocketMessage`** - WebSocket message model for client-server communication

### Chatbots

- **`RegularChatbot`** - Handles new service requests and general inquiries
- **`ModifyChatbot`** - Handles updates to existing requests

## Configuration

### Environment Variables

- `OPENAI_API_KEY` - OpenAI API key for GPT-4
- `MongoDB_URL` - MongoDB connection string
- `HOST` - Server host (default: 0.0.0.0)
- `PORT` - Server port (default: 4000)

### Customization

- Edit `Chatbot/Prompt.py` for regular chatbot behavior
- Edit `Modify/Prompt.py` for modify chatbot behavior
- Modify `config.py` for server configuration
- Update learning data in MongoDB for knowledge base changes

## Requirements

- Python 3.8+
- OpenAI API key
- MongoDB instance
- Internet connection for API calls

## Dependencies

- `fastapi>=0.104.0` - Web framework
- `uvicorn[standard]>=0.24.0` - ASGI server
- `websockets>=12.0` - WebSocket support
- `pydantic>=2.0.0` - Data validation
- `python-multipart>=0.0.6` - Form data handling
- `openai>=1.0.0` - OpenAI API client
- `python-dotenv>=1.0.0` - Environment variables
- `pymongo>=4.0.0` - MongoDB client
- `faiss-cpu>=1.7.0` - Vector similarity search
- `sentence-transformers>=2.0.0` - Text embeddings

## Development

### Running in Development Mode

```bash
# Start with auto-reload
uvicorn app:app --reload --host 0.0.0.0 --port 4000
```

### Testing

```bash
# Test regular chatbot WebSocket
python regular_chatbot_websocket_test.py

# Test modify chatbot WebSocket
python modify_chatbot_websocket_test.py

# Test with custom host/port
python regular_chatbot_websocket_test.py --host 192.168.1.100 --port 8001
```

## Node.js Frontend Integration

### WebSocket Connection Example

```javascript
// Connect to regular chatbot
const ws = new WebSocket('ws://localhost:4000/ws/regular');

ws.onopen = function(event) {
    console.log('Connected to AURA Regular Chatbot');
};

ws.onmessage = function(event) {
    const data = JSON.parse(event.data);
    
    if (data.type === 'welcome') {
        console.log('Welcome:', data.message);
        console.log('Session ID:', data.session_id);
    } else if (data.type === 'response') {
        console.log('Bot Response:', data.message);
    } else if (data.type === 'redirect') {
        console.log('Redirect:', data.message);
    }
};

// Send message
function sendMessage(message) {
    ws.send(JSON.stringify({
        type: 'chat',
        message: message
    }));
}

// Send ping
function ping() {
    ws.send(JSON.stringify({
        type: 'ping'
    }));
}
```

### WebSocket Event Handling

```javascript
ws.onclose = function(event) {
    console.log('WebSocket connection closed');
};

ws.onerror = function(error) {
    console.error('WebSocket error:', error);
};
```

## 🎯 Frontend Development Summary

### **Key Takeaways for Frontend Development**

#### **1. Two-Chatbot Architecture**
- **Regular Chatbot** (`/ws/regular`): For new service requests, pricing, information
- **Modify Chatbot** (`/ws/modify`): For updates, changes, cancellations
- **Smart Routing**: Implement keyword detection to route users to the right chatbot

#### **2. Recommended Frontend Structure**
```
Frontend App
├── components/
│   ├── ChatInterface.jsx
│   ├── ChatbotSelector.jsx
│   └── ErrorBoundary.jsx
├── hooks/
│   ├── useWebSocket.js
│   ├── useChatbotManager.js
│   └── useAnalytics.js
├── store/
│   └── chatStore.js (Zustand/Redux)
└── utils/
    ├── chatbotRouter.js
    └── errorHandler.js
```

#### **3. Essential Features to Implement**
- **Connection Management**: Handle WebSocket connections for both chatbots
- **Session Persistence**: Store session IDs and message history
- **Error Recovery**: Automatic reconnection and graceful degradation
- **User Guidance**: Clear instructions and examples for each chatbot
- **Analytics**: Track user interactions and chatbot performance

#### **4. User Experience Best Practices**
- **Clear Visual Distinction**: Different colors/themes for each chatbot
- **Contextual Placeholders**: Relevant input hints for each chatbot type
- **Smart Suggestions**: Quick action buttons based on chatbot type
- **Smooth Transitions**: Handle redirections between chatbots gracefully

#### **5. Technical Implementation**
- **WebSocket Management**: Separate connections for each chatbot
- **State Management**: Centralized state for messages, sessions, and connections
- **Error Handling**: Comprehensive error boundaries and recovery mechanisms
- **Performance**: Connection pooling, message batching, and efficient re-renders

## 🚨 Important Backend Updates & Bug Fixes

### **Recent Improvements Made**

#### **1. Enhanced Error Handling**
- ✅ **JSON Validation**: Added proper error handling for malformed JSON messages
- ✅ **Connection Recovery**: Improved WebSocket disconnection handling
- ✅ **Timeout Management**: Better handling of long-running requests

#### **2. Message Format Validation**
The backend now validates all incoming WebSocket messages and returns helpful error messages:

```json
{
  "type": "error",
  "message": "Invalid message format. Please send valid JSON.",
  "chatbot_type": "regular",
  "session_id": "uuid-session-id"
}
```

#### **3. Improved Session Management**
- ✅ **Session Persistence**: Better session tracking across reconnections
- ✅ **Cleanup Handling**: Proper cleanup of resources on disconnect
- ✅ **Memory Management**: Reduced memory leaks in long-running sessions

### **Frontend Integration Requirements**

#### **1. Error Message Handling**
Your frontend must handle these new error message types:

```javascript
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  
  switch (data.type) {
    case 'error':
      // Handle server errors gracefully
      showErrorMessage(data.message);
      break;
    case 'welcome':
      // Handle welcome message
      handleWelcome(data);
      break;
    case 'response':
      // Handle bot response
      handleResponse(data);
      break;
    case 'redirect':
      // Handle chatbot redirection
      handleRedirect(data);
      break;
    default:
      console.warn('Unknown message type:', data.type);
  }
};
```

#### **2. Connection Resilience**
Implement robust connection handling:

```javascript
class WebSocketManager {
  constructor(endpoint) {
    this.endpoint = endpoint;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.reconnectDelay = 1000;
  }
  
  connect() {
    this.ws = new WebSocket(this.endpoint);
    
    this.ws.onopen = () => {
      this.reconnectAttempts = 0;
      this.onConnected();
    };
    
    this.ws.onclose = (event) => {
      if (!event.wasClean && this.reconnectAttempts < this.maxReconnectAttempts) {
        this.scheduleReconnect();
      }
    };
    
    this.ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      this.onError(error);
    };
  }
  
  scheduleReconnect() {
    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
    
    setTimeout(() => {
      console.log(`Reconnecting... (attempt ${this.reconnectAttempts})`);
      this.connect();
    }, delay);
  }
}
```

#### **3. Message Validation**
Always validate messages before sending:

```javascript
function sendMessage(message) {
  if (!message || typeof message !== 'string') {
    throw new Error('Message must be a non-empty string');
  }
  
  if (message.length > 1000) {
    throw new Error('Message too long (max 1000 characters)');
  }
  
  const messageData = {
    type: 'chat',
    message: message.trim()
  };
  
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(messageData));
  } else {
    throw new Error('WebSocket not connected');
  }
}
```

#### **4. Rate Limiting Prevention**
Implement client-side rate limiting to prevent spam:

```javascript
class RateLimiter {
  constructor(maxRequests = 10, windowMs = 60000) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    this.requests = [];
  }
  
  canMakeRequest() {
    const now = Date.now();
    
    // Remove old requests outside the window
    this.requests = this.requests.filter(time => now - time < this.windowMs);
    
    return this.requests.length < this.maxRequests;
  }
  
  recordRequest() {
    this.requests.push(Date.now());
  }
}

// Usage
const rateLimiter = new RateLimiter(10, 60000); // 10 requests per minute

function sendMessage(message) {
  if (!rateLimiter.canMakeRequest()) {
    showError('Too many messages. Please wait before sending another message.');
    return;
  }
  
  rateLimiter.recordRequest();
  // Send message...
}
```

### **Production Deployment Checklist**

#### **Backend Configuration**
- [ ] Set proper environment variables
- [ ] Configure MongoDB connection string
- [ ] Set up proper logging
- [ ] Configure CORS for production domains
- [ ] Set up health monitoring

#### **Frontend Configuration**
- [ ] Update WebSocket URLs for production
- [ ] Implement proper error boundaries
- [ ] Add connection status indicators
- [ ] Set up analytics tracking
- [ ] Test both chatbot endpoints

#### **Security Considerations**
- [ ] Validate all user inputs
- [ ] Implement proper CORS policies
- [ ] Use HTTPS/WSS in production
- [ ] Monitor for suspicious activity
- [ ] Implement rate limiting

### **Troubleshooting Guide**

#### **Common Issues & Solutions**

1. **WebSocket Connection Fails**
   - Check if backend server is running
   - Verify WebSocket URL is correct
   - Check CORS configuration
   - Ensure firewall allows WebSocket connections

2. **Messages Not Received**
   - Check WebSocket connection state
   - Verify message format is valid JSON
   - Check browser console for errors
   - Ensure session ID is being tracked

3. **Chatbot Responses Are Slow**
   - Check OpenAI API key is valid
   - Verify MongoDB connection
   - Check server logs for errors
   - Consider implementing loading indicators

4. **Session Management Issues**
   - Ensure session IDs are stored properly
   - Check for session cleanup on disconnect
   - Verify MongoDB connection for logging
   - Test reconnection scenarios

### **Performance Optimization**

#### **Backend Optimizations**
- Use connection pooling for MongoDB
- Implement caching for frequently accessed data
- Monitor memory usage and session cleanup
- Use async/await properly throughout

#### **Frontend Optimizations**
- Implement message batching for high-frequency updates
- Use React.memo for chat components
- Implement virtual scrolling for long chat histories
- Use Web Workers for heavy computations

### **Monitoring & Analytics**

#### **Key Metrics to Track**
- WebSocket connection success rate
- Message response times
- User engagement per chatbot type
- Error rates and types
- Session duration and completion rates

#### **Recommended Tools**
- **Backend**: Structured logging with timestamps
- **Frontend**: Error tracking (Sentry, LogRocket)
- **Analytics**: User behavior tracking
- **Monitoring**: Uptime monitoring and health checks

## 🧪 Testing & Development

### **Test Files Created**

I've created two comprehensive test files for you to test both chatbots:

#### **1. `test_regular_chatbot.py`**
- Tests the regular chatbot WebSocket endpoint (`/ws/regular`)
- Interactive input loop with proper response waiting
- Real-time conversation flow
- Session management and error handling

#### **2. `test_modify_chatbot.py`**
- Tests the modify chatbot WebSocket endpoint (`/ws/modify`)
- Interactive input loop with proper response waiting
- Real-time conversation flow
- Session management and error handling

### **How to Use Test Files**

1. **Start your backend server**:
   ```bash
   python run.py
   ```

2. **Test regular chatbot**:
   ```bash
   python test_regular_chatbot.py
   ```

3. **Test modify chatbot**:
   ```bash
   python test_modify_chatbot.py
   ```

### **Test File Features**

Both test files include:
- ✅ **Proper Turn-Based Flow**: Input only appears after bot response
- ✅ **Real-Time Communication**: Instant WebSocket messaging
- ✅ **Session Tracking**: Shows session IDs and manages state
- ✅ **Error Handling**: Graceful handling of connection issues
- ✅ **Clean Exit**: Type 'quit', 'exit', or 'q' to stop
- ✅ **Connection Status**: Shows connection state and errors

### **Example Test Session**

```
🤖 AURA Regular Chatbot Tester
========================================
🔌 Connecting to ws://localhost:4000/ws/regular...
✅ Connected successfully!
🚀 Starting interactive session...
📝 Type your messages below. Type 'quit' or 'exit' to stop.

🤖 Welcome to AURA Regular Chatbot! How can I help you today?
📋 Session ID: 3db75723-748d-4fc7-a980-3773e521c0e7
💬 You can now start chatting! Type 'quit' or 'exit' to stop.

👤 You: hello
🤖 Bot: Hello! Welcome to our truck shop. How can I assist you today?

👤 You: I need brake pad replacement
🤖 Bot: I'll help you with brake pad replacement. Let me gather some information...

👤 You: quit
👋 Goodbye!
🔌 Connection closed
```

## 🚀 Deployment

### Environment Variables

Create a `.env` file in the root directory:

```env
# MongoDB Configuration
MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/aura?retryWrites=true&w=majority

# Server Configuration
HOST=0.0.0.0
PORT=4000
DEBUG=false

# Learning Data Configuration
LEARNING_DATA_PATH=Data/learning_data
```

### Production Deployment

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Set Environment Variables**:
   ```bash
   export MONGODB_URL="your-mongodb-connection-string"
   export HOST="0.0.0.0"
   export PORT="4000"
   export DEBUG="false"
   ```

3. **Run the Server**:
   ```bash
   python run.py
   ```

4. **Using Gunicorn (Production)**:
   ```bash
   gunicorn app:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:4000
   ```

### Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 4000

CMD ["python", "run.py"]
```

Build and run:

```bash
docker build -t aura-backend .
docker run -p 4000:4000 --env-file .env aura-backend
```

## 📊 Monitoring and Logs

### Health Check

The server provides a health check endpoint:

```bash
curl http://localhost:4000/health
```

### Logs

The application uses structured logging with timestamps and log levels:

```
03:39:18 | INFO | AURA | 🚀 Starting AURA Backend API...
03:39:26 | INFO | AURA | ✅ Learning Service initialized
03:39:42 | INFO | AURA | ✅ Chat Service initialized
03:39:42 | INFO | AURA | ✅ AURA Backend API ready!
```

### MongoDB Monitoring

All chat sessions are automatically logged to MongoDB with:
- Session IDs for tracking
- Timestamps for analytics
- Chatbot type classification
- Complete conversation history

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation above

---

**AURA Backend API** - Professional truck service chatbot system with WebSocket support and MongoDB integration.