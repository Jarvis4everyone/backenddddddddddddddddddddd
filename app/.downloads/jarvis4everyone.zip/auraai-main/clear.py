"""
Cleanup utility for the Aura Chatbot project.
This script removes Python cache files, compiled bytecode, and temporary files.
Run this to clean up the project directory before deployment or when troubleshooting import issues.
"""

import os
import shutil

def clean_cache():
    """
    Delete all __pycache__ directories and .pyc compiled Python files.
    
    This function walks through the entire project directory structure and:
    1. Removes all __pycache__ directories which contain compiled Python modules
    2. Deletes any .pyc files that might exist outside those directories
    
    Returns:
        None, but prints information about deleted files
    """
    # Get the directory where this script is located - the project root
    root_dir = os.path.dirname(os.path.abspath(__file__))
    deleted_cache = 0  # Counter for deleted cache directories
    deleted_pyc = 0    # Counter for deleted .pyc files
    
    print("Cleaning Python cache files...")
    
    # Walk through all directories and files in the project
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Clean __pycache__ directories
        if '__pycache__' in dirnames:
            cache_path = os.path.join(dirpath, '__pycache__')
            shutil.rmtree(cache_path)  # Recursively delete the directory and contents
            deleted_cache += 1
            print(f"Deleted: {cache_path}")
        
        # Clean .pyc files (compiled Python files)
        for filename in filenames:
            if filename.endswith('.pyc'):
                pyc_path = os.path.join(dirpath, filename)
                os.remove(pyc_path)  # Delete the file
                deleted_pyc += 1
                print(f"Deleted: {pyc_path}")
    
    # Print summary of cleanup operation
    print(f"\nRemoved {deleted_cache} cache directories and {deleted_pyc} .pyc files")

def clean_temp_files():
    """
    Delete temporary files that might be created during testing or by the OS.
    
    This function identifies and removes various types of temporary files:
    - OS-specific files like .DS_Store (macOS)
    - Temp files with .tmp extension
    - Log files
    - Backup files
    - Files prefixed with 'temp_'
    
    Returns:
        None, but prints information about deleted files
    """
    root_dir = os.path.dirname(os.path.abspath(__file__))
    deleted_files = 0  # Counter for deleted temporary files
    
    # Patterns to match for temp files
    # Each pattern defines a type of file to be cleaned
    temp_patterns = [
        '.DS_Store',         # MacOS system files (stores folder view options)
        '*.tmp',             # Temporary files with .tmp extension
        '*.log',             # Log files
        '*.bak',             # Backup files
        'temp_*'             # Files starting with temp_
    ]
    
    print("\nCleaning temporary files...")
    
    # Walk through all directories and files
    for dirpath, dirnames, filenames in os.walk(root_dir):
        for filename in filenames:
            for pattern in temp_patterns:
                # Case 1: Pattern starts with * (match by file extension)
                if pattern.startswith('*'):
                    if filename.endswith(pattern[1:]):
                        file_path = os.path.join(dirpath, filename)
                        try:
                            os.remove(file_path)
                            deleted_files += 1
                            print(f"Deleted: {file_path}")
                        except:
                            print(f"Failed to delete: {file_path}")
                        break
                # Case 2: Pattern ends with * (match by file prefix)
                elif pattern.endswith('*'):
                    if filename.startswith(pattern[:-1]):
                        file_path = os.path.join(dirpath, filename)
                        try:
                            os.remove(file_path)
                            deleted_files += 1
                            print(f"Deleted: {file_path}")
                        except:
                            print(f"Failed to delete: {file_path}")
                        break
                # Case 3: Exact match with the full pattern
                elif pattern == filename:
                    file_path = os.path.join(dirpath, filename)
                    try:
                        os.remove(file_path)
                        deleted_files += 1
                        print(f"Deleted: {file_path}")
                    except:
                        print(f"Failed to delete: {file_path}")
                    break
    
    # Print summary of temporary file cleanup
    print(f"\nRemoved {deleted_files} temporary files")

def clean_all():
    """
    Run all cleaning functions in sequence.
    
    This is the main function that orchestrates the entire cleanup process:
    1. First cleans Python cache files
    2. Then cleans temporary files
    3. Prints completion message
    """
    clean_cache()        # Clean Python cache files
    clean_temp_files()   # Clean temporary files
    print("\nCleanup complete!")

if __name__ == "__main__":
    clean_all()

