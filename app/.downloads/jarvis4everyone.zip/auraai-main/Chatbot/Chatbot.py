"""
Modular Chatbot Implementation using OpenAI
This module provides a clean, modular chatbot interface with temporary chat logging.
"""

import os
import sys
from typing import List, Dict, Any, Optional
from openai import OpenAI
from dotenv import load_dotenv
from .Prompt import get_system_prompt
from .MongoDBService import MongoDBService

# Add parent directory to path for LearningManager
sys.path.append('..')
# Import LearningManager only when needed to avoid circular imports

load_dotenv()

class Chatbot:
    """
    A modular chatbot class that uses OpenAI's GPT-4 model for conversations.
    
    Features:
    - Uses OpenAI's best available model (GPT-4)
    - Maintains temporary chat history during session
    - Modular design for easy integration
    - Clean conversation management
    """
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4", shared_learning_manager=None, input_language: str = "en-US"):
        """
        Initialize the chatbot.
        
        Args:
            api_key (str, optional): OpenAI API key. If None, will try to get from environment.
            model (str): The OpenAI model to use. Defaults to GPT-4.
            shared_learning_manager: Shared LearningManager instance to avoid duplicate initialization.
            input_language (str): User's input language code for responses.
        """
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable or pass api_key parameter.")
        
        self.client = OpenAI(api_key=self.api_key)
        self.model = model
        self.input_language = input_language
        self.system_prompt = get_system_prompt(input_language)
        
        # Initialize MongoDB service
        try:
            self.mongodb_service = MongoDBService()
        except Exception as e:
            print(f"⚠️ Warning: MongoDB service initialization failed: {str(e)}")
            self.mongodb_service = None
        
        # Use shared Learning Manager if provided, otherwise create new one
        if shared_learning_manager:
            self.learning_manager = shared_learning_manager
        else:
            try:
                from Data.LearningManager import LearningManager
                self.learning_manager = LearningManager()
            except Exception as e:
                print(f"⚠️ Warning: Learning Manager initialization failed: {str(e)}")
                self.learning_manager = None
        
        # Temporary chat history (resets on each session)
        self.chat_history: List[Dict[str, str]] = [
            {"role": "system", "content": self.system_prompt}
        ]
    
    def update_language(self, input_language: str):
        """Update the chatbot's language and regenerate system prompt."""
        self.input_language = input_language
        self.system_prompt = get_system_prompt(input_language)
        
        # Update the first message in chat history (system prompt)
        if self.chat_history and self.chat_history[0]["role"] == "system":
            self.chat_history[0]["content"] = self.system_prompt
    
    def add_message(self, role: str, content: str) -> None:
        """
        Add a message to the chat history.
        
        Args:
            role (str): The role of the message sender ('user' or 'assistant')
            content (str): The message content
        """
        if role not in ["user", "assistant"]:
            raise ValueError("Role must be 'user' or 'assistant'")
        
        self.chat_history.append({"role": role, "content": content})
    
    def get_response(self, user_message: str) -> str:
        """
        Get a response from the chatbot for the given user message.
        
        Args:
            user_message (str): The user's input message
            
        Returns:
            str: The chatbot's response
            
        Raises:
            Exception: If there's an error with the OpenAI API call
        """
        try:
            # Add user message to history
            self.add_message("user", user_message)
            
            # Get relevant context from Learning Manager if available
            context = ""
            if self.learning_manager:
                context = self.learning_manager.get_context_for_query(user_message)
            
            # Prepare messages with context
            messages = self.chat_history.copy()
            if context:
                # Add context as a strong system instruction
                context_message = f"""IMPORTANT: You must answer based on the following knowledge base information. Use this data to provide accurate, specific answers. Do not make up information that's not in this knowledge base.

KNOWLEDGE BASE DATA:
{context}

INSTRUCTIONS: Always reference the specific information from the knowledge base above when answering questions. If the user asks about services, pricing, contact information, or any other details, use ONLY the information provided in the knowledge base."""
                messages.append({"role": "system", "content": context_message})
            
            # Get response from OpenAI
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=1000,
                temperature=0.7,
                top_p=1.0,
                frequency_penalty=0.0,
                presence_penalty=0.0
            )
            
            # Extract assistant's response
            assistant_response = response.choices[0].message.content.strip()
            
            # Check if this is a confirmation response and save to MongoDB
            if self.mongodb_service:
                try:
                    # Process the response and get result
                    result = self.mongodb_service.process_chatbot_response(assistant_response)
                    
                    # Handle different result statuses
                    if result["status"] == "saved":
                        # Extract customer name from the response for the clean message
                        customer_name = self._extract_customer_name_from_response(assistant_response)
                        if customer_name:
                            # Get the MongoDB document ID from the service
                            document_id = self.mongodb_service.get_last_saved_id()
                            
                            # Create clean response
                            assistant_response = f"""Thank you for confirming the details, {customer_name}.
Your service request has been saved with ID: {document_id}
I would like to inform you that your service request has been saved in our system.
Is there anything else you need assistance with?"""
                    
                    elif result["status"] == "already_exists":
                        # Extract customer name from the response
                        customer_name = self._extract_customer_name_from_response(assistant_response)
                        if customer_name:
                            # Create response for existing request
                            assistant_response = f"""Thank you for confirming the details, {customer_name}.
That same request already exists. If you want to modify your request, we can do that.
Is there anything else you need assistance with?"""
                    
                    elif result["status"] == "already_processed":
                        # This request was already processed in this session, don't modify response
                        pass
                    
                    elif result["status"] == "save_error":
                        # Keep original response if save failed
                        pass
                    
                    elif result["status"] == "no_dictionary":
                        # No dictionary found, keep original response
                        pass
                    
                except Exception as e:
                    print(f"⚠️ Warning: Failed to process MongoDB response: {str(e)}")
                    import traceback
                    print(f"   - Traceback: {traceback.format_exc()}")
            
            # Add assistant response to history
            self.add_message("assistant", assistant_response)
            
            return assistant_response
            
        except Exception as e:
            error_msg = f"Error getting response: {str(e)}"
            self.add_message("assistant", error_msg)
            return error_msg
    
    def get_chat_history(self) -> List[Dict[str, str]]:
        """
        Get the current chat history (excluding system prompt).
        
        Returns:
            List[Dict[str, str]]: List of chat messages
        """
        return self.chat_history[1:]  # Exclude system prompt
    
    def clear_history(self) -> None:
        """
        Clear the chat history and reset to initial state.
        """
        self.chat_history = [
            {"role": "system", "content": self.system_prompt}
        ]
    
    def get_conversation_summary(self) -> str:
        """
        Get a summary of the current conversation.
        
        Returns:
            str: A formatted summary of the conversation
        """
        if len(self.chat_history) <= 1:
            return "No conversation yet."
        
        summary = "Conversation Summary:\n"
        summary += "=" * 50 + "\n"
        
        for i, message in enumerate(self.chat_history[1:], 1):
            role = message["role"].title()
            content = message["content"][:100] + "..." if len(message["content"]) > 100 else message["content"]
            summary += f"{i}. {role}: {content}\n"
        
        return summary
    
    def set_model(self, model: str) -> None:
        """
        Change the OpenAI model being used.
        
        Args:
            model (str): The new model to use
        """
        self.model = model
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about the current chatbot configuration.
        
        Returns:
            Dict[str, Any]: Configuration information
        """
        return {
            "model": self.model,
            "system_prompt_length": len(self.system_prompt),
            "conversation_length": len(self.chat_history) - 1,  # Exclude system prompt
            "api_key_set": bool(self.api_key),
            "mongodb_connected": self.mongodb_service is not None
        }
    
    def close_mongodb_connection(self):
        """Close MongoDB connection if it exists."""
        if self.mongodb_service:
            self.mongodb_service.close_connection()
    
    def _extract_customer_name_from_response(self, response_text: str) -> Optional[str]:
        """
        Extract customer name from the chatbot response.
        
        Args:
            response_text (str): The chatbot's response text
            
        Returns:
            Optional[str]: Customer name if found, None otherwise
        """
        try:
            # Look for "FullName" in the JSON part of the response
            import re
            pattern = r'"FullName":\s*"([^"]+)"'
            match = re.search(pattern, response_text)
            if match:
                return match.group(1)
            
            # Fallback: look for common patterns
            patterns = [
                r'Thank you for confirming the details, ([^.]+)\.',
                r'Hello ([^,]+),',
                r'Great! Thank you for confirming, ([^.]+)\.'
            ]
            
            for pattern in patterns:
                match = re.search(pattern, response_text)
                if match:
                    return match.group(1).strip()
            
            return None
        except Exception:
            return None


def create_chatbot(api_key: Optional[str] = None, model: str = "gpt-4", shared_learning_manager=None) -> Chatbot:
    """
    Factory function to create a new chatbot instance.
    
    Args:
        api_key (str, optional): OpenAI API key
        model (str): The OpenAI model to use
        shared_learning_manager: Shared LearningManager instance to avoid duplicate initialization
        
    Returns:
        Chatbot: A new chatbot instance
    """
    return Chatbot(api_key=api_key, model=model, shared_learning_manager=shared_learning_manager)
