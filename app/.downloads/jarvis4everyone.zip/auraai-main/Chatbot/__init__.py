"""
Aura Chatbot Package
A modular chatbot implementation using OpenAI's GPT-4 model.
"""

from .Chatbot import Chatbot, create_chatbot
from .Prompt import get_system_prompt

__version__ = "1.0.0"
__author__ = "Aura Backend"

__all__ = ["Chatbot", "create_chatbot", "get_system_prompt"]
