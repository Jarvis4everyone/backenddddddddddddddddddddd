"""
MongoDB Service for saving service requests
This module handles all MongoDB operations for the chatbot.
"""

import os
import json
import re
from datetime import datetime
from typing import Dict, Any, Optional, List
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class MongoDBService:
    """
    Service class to handle MongoDB operations for service requests.
    """
    
    def __init__(self):
        """Initialize MongoDB connection."""
        self.mongodb_url = os.getenv("MongoDB_URL")
        if not self.mongodb_url:
            raise ValueError("MongoDB_URL not found in environment variables")
        
        self.client = None
        self.db = None
        self.collection = None
        self.last_saved_id = None  # Store the last saved document ID
        self.processed_requests = set()  # Track processed requests to prevent duplicates
        self._connect()
    
    def _connect(self):
        """Establish connection to MongoDB."""
        try:
            self.client = MongoClient(
                self.mongodb_url, 
                serverSelectionTimeoutMS=5000,
                retryWrites=True,
                w='majority'
            )
            # Test the connection
            self.client.admin.command('ping')
            self.db = self.client['aura']
            self.collection = self.db['customer_requests']
            print("✅ Connected to MongoDB successfully")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            print(f"❌ Failed to connect to MongoDB: {str(e)}")
            raise
    
    def detect_and_extract_dictionary(self, response_text: str) -> Optional[Dict[str, Any]]:
        """
        Robust dictionary detector that finds ANY dictionary in the response.
        
        Args:
            response_text (str): The chatbot's response text
            
        Returns:
            Optional[Dict[str, Any]]: Extracted dictionary data or None if not found
        """
        
        # Method 1: Look for JSON objects with curly braces
        json_objects = self._extract_json_objects(response_text)
        if json_objects:
            for i, obj in enumerate(json_objects):
                parsed_data = self._parse_json_object(obj)
                if parsed_data:
                    return parsed_data
        
        # Method 2: Look for dictionary-like structures with quotes
        dict_patterns = self._extract_dict_patterns(response_text)
        if dict_patterns:
            for i, pattern in enumerate(dict_patterns):
                parsed_data = self._parse_dict_pattern(pattern)
                if parsed_data:
                    return parsed_data
        
        # Method 3: Look for key-value pairs in the text
        kv_pairs = self._extract_key_value_pairs(response_text)
        if kv_pairs:
            parsed_data = self._parse_key_value_pairs(kv_pairs)
            if parsed_data:
                return parsed_data
        
        return None
    
    def _extract_json_objects(self, text: str) -> List[str]:
        """Extract all JSON-like objects from text."""
        import re
        # Find all objects that start with { and end with }
        pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
        matches = re.findall(pattern, text, re.DOTALL)
        return matches
    
    def _extract_dict_patterns(self, text: str) -> List[str]:
        """Extract dictionary-like patterns with quotes."""
        import re
        # Look for patterns like "key": "value"
        pattern = r'"[^"]+"\s*:\s*"[^"]+"'
        matches = re.findall(pattern, text)
        return matches
    
    def _extract_key_value_pairs(self, text: str) -> Dict[str, str]:
        """Extract key-value pairs from text."""
        import re
        pairs = {}
        
        # Look for patterns like "FullName": "John Doe"
        pattern = r'"([^"]+)"\s*:\s*"([^"]+)"'
        matches = re.findall(pattern, text)
        for key, value in matches:
            pairs[key] = value
        
        return pairs
    
    def _parse_json_object(self, json_str: str) -> Optional[Dict[str, Any]]:
        """Parse a JSON object string."""
        try:
            import json
            data = json.loads(json_str)
            
            # Validate required fields
            required_fields = ['Status', 'FullName', 'ContactNumber', 'TruckId', 'TruckCompanyName', 'ServiceType', 'Priority']
            if all(field in data for field in required_fields):
                return self._convert_to_service_request(data)
            
        except json.JSONDecodeError:
            pass
        
        return None
    
    def _parse_dict_pattern(self, pattern: str) -> Optional[Dict[str, Any]]:
        """Parse dictionary pattern."""
        # This would parse individual key-value pairs
        # For now, return None as this is a fallback method
        return None
    
    def _parse_key_value_pairs(self, pairs: Dict[str, str]) -> Optional[Dict[str, Any]]:
        """Parse key-value pairs into service request."""
        try:
            # Check if we have enough data
            required_keys = ['Status', 'FullName', 'ContactNumber', 'TruckId', 'TruckCompanyName', 'ServiceType', 'Priority']
            if all(key in pairs for key in required_keys):
                return self._convert_to_service_request(pairs)
        except Exception as e:
            pass
        
        return None
    
    def _convert_to_service_request(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Convert parsed data to service request format."""
        try:
            # Convert service_type from list of strings to list of objects
            service_types = data.get('ServiceType', [])
            if isinstance(service_types, list):
                service_type_objects = []
                for service in service_types:
                    if isinstance(service, str):
                        service_type_objects.append({
                            "name": service,
                            "service_status": "pending"
                        })
                    elif isinstance(service, dict) and "name" in service:
                        service_type_objects.append({
                            "name": service["name"],
                            "service_status": service.get("service_status", "pending")
                        })
            else:
                # Handle single service as string
                service_type_objects = [{
                    "name": str(service_types),
                    "service_status": "pending"
                }]
            
            service_request = {
                "status": data.get('Status', 'requested').lower(),
                "customer_name": data.get('FullName', ''),
                "contact_number": data.get('ContactNumber', ''),
                "truck_id": data.get('TruckId', ''),
                "truck_company_name": data.get('TruckCompanyName', ''),
                "service_type": service_type_objects,
                "priority": data.get('Priority', '').lower(),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "notes": data.get('Notes', 'No notes.'),
                "created_by": "auraai",
                "source": "aiassistantaura",
                "auto_approved": False
            }
            
            return service_request
            
        except Exception as e:
            print(f"❌ Error converting to service request: {str(e)}")
            return None
    
    def save_service_request(self, service_request: Dict[str, Any]) -> bool:
        """
        Save new service request to MongoDB with comprehensive logging.
        
        Args:
            service_request (Dict[str, Any]): Service request data
            
        Returns:
            bool: True if saved successfully, False otherwise
        """
        try:
            
            # Insert new document
            result = self.collection.insert_one(service_request)
            
            
            self.last_saved_id = str(result.inserted_id)
            
            # Verify the document was actually saved
            saved_doc = self.collection.find_one({"_id": result.inserted_id})
            if saved_doc:
                return True
            else:
                return False
                
        except Exception as e:
            return False
    
    
    def check_existing_request(self, truck_id: str, customer_name: str) -> Optional[Dict[str, Any]]:
        """
        Check if a service request with the given truck ID and customer name already exists.
        
        Args:
            truck_id (str): The truck ID to check
            customer_name (str): The customer name to check
            
        Returns:
            Optional[Dict[str, Any]]: Existing request data if found, None otherwise
        """
        try:
            existing_request = self.collection.find_one({
                "truck_id": truck_id,
                "customer_name": customer_name
            })
            
            if existing_request:
                # Convert ObjectIds to strings for JSON serialization
                existing_request = self._convert_object_ids_to_strings(existing_request)
            
            return existing_request
        except Exception as e:
            print(f"❌ Error checking existing request: {str(e)}")
            return None
    
    def get_all_customer_requests(self, limit: int = 100, skip: int = 0) -> List[Dict[str, Any]]:
        """
        Retrieve all customer requests from MongoDB with pagination.
        
        Args:
            limit (int): Maximum number of requests to return
            skip (int): Number of requests to skip (for pagination)
            
        Returns:
            List[Dict[str, Any]]: List of customer requests
        """
        try:
            cursor = self.collection.find().sort("created_at", -1).skip(skip).limit(limit)
            requests = list(cursor)
            
            # Debug: Print sample data structure
            if requests:
                sample = requests[0]
                print(f"🔍 DEBUG: Sample request keys: {list(sample.keys())}")
                for key, value in sample.items():
                    print(f"🔍 DEBUG: {key}: {type(value)} = {value}")
            
            # Convert all ObjectId fields to strings for JSON serialization
            converted_requests = []
            for request in requests:
                converted_request = self._convert_object_ids_to_strings(request)
                converted_requests.append(converted_request)
            
            return converted_requests
        except Exception as e:
            print(f"❌ Error retrieving customer requests: {str(e)}")
            return []
    
    def _convert_object_ids_to_strings(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively convert all ObjectId fields to strings in a MongoDB document.
        This makes the document JSON-serializable and future-proof.
        
        Args:
            document: MongoDB document (dict)
            
        Returns:
            Dict[str, Any]: Document with ObjectIds converted to strings
        """
        if not isinstance(document, dict):
            return document
        
        converted_doc = {}
        
        for key, value in document.items():
            if isinstance(value, dict):
                # Handle nested objects (like {"$oid": "..."})
                if "$oid" in value:
                    converted_doc[key] = str(value["$oid"])
                elif "$date" in value:
                    # Handle date objects
                    converted_doc[key] = value["$date"]
                else:
                    # Recursively convert nested dictionaries
                    converted_doc[key] = self._convert_object_ids_to_strings(value)
            elif isinstance(value, list):
                # Handle lists that might contain ObjectIds
                converted_doc[key] = [
                    self._convert_object_ids_to_strings(item) if isinstance(item, dict) 
                    else str(item) if self._is_object_id(item)
                    else item
                    for item in value
                ]
            elif self._is_object_id(value):
                # Handle direct ObjectId objects
                converted_doc[key] = str(value)
            elif hasattr(value, 'isoformat'):
                # Handle datetime objects
                converted_doc[key] = value.isoformat()
            else:
                # Keep other values as-is
                converted_doc[key] = value
        
        return converted_doc
    
    def _is_object_id(self, value) -> bool:
        """
        Check if a value is an ObjectId object.
        
        Args:
            value: Value to check
            
        Returns:
            bool: True if value is an ObjectId
        """
        try:
            # Check by class name
            if hasattr(value, '__class__') and value.__class__.__name__ == 'ObjectId':
                return True
            # Check by module name
            if hasattr(value, '__module__') and 'bson' in str(value.__module__):
                return True
            # Check by string representation pattern
            if hasattr(value, '__str__'):
                str_val = str(value)
                if len(str_val) == 24 and all(c in '0123456789abcdef' for c in str_val):
                    return True
            return False
        except Exception:
            return False
    
    def get_customer_requests_count(self) -> int:
        """
        Get the total count of customer requests.
        
        Returns:
            int: Total number of customer requests
        """
        try:
            return self.collection.count_documents({})
        except Exception as e:
            print(f"❌ Error getting customer requests count: {str(e)}")
            return 0
    
    def get_customer_requests_by_status(self, status: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get customer requests filtered by status.
        
        Args:
            status (str): Status to filter by (e.g., "requested", "approved", "completed")
            limit (int): Maximum number of requests to return
            
        Returns:
            List[Dict[str, Any]]: List of customer requests with the specified status
        """
        try:
            cursor = self.collection.find({"status": status}).sort("created_at", -1).limit(limit)
            requests = list(cursor)
            
            # Convert all ObjectId fields to strings for JSON serialization
            converted_requests = []
            for request in requests:
                converted_request = self._convert_object_ids_to_strings(request)
                converted_requests.append(converted_request)
            
            return converted_requests
        except Exception as e:
            print(f"❌ Error retrieving customer requests by status: {str(e)}")
            return []

    def process_chatbot_response(self, response_text: str) -> Dict[str, Any]:
        """
        Process EVERY chatbot response and save ANY dictionary found to MongoDB.
        
        Args:
            response_text (str): The chatbot's response text
            
        Returns:
            Dict[str, Any]: Result dictionary with status and message
        """
        
        # Use the robust dictionary detector
        service_request = self.detect_and_extract_dictionary(response_text)
        
        if not service_request:
            return {"status": "no_dictionary", "message": "No dictionary found in response"}
        
        
        # Create a unique key for this request to prevent duplicates in the same session
        request_key = f"{service_request['customer_name']}_{service_request['truck_id']}_{service_request['service_type']}"
        
        # Check if we've already processed this request in this session
        if request_key in self.processed_requests:
            return {"status": "already_processed", "message": "This request has already been processed in this session"}
        
        # Check if a request with the same truck_id and customer_name already exists
        existing_request = self.check_existing_request(
            service_request["truck_id"], 
            service_request["customer_name"]
        )
        
        if existing_request:
            self.processed_requests.add(request_key)
            return {
                "status": "already_exists", 
                "message": f"Request already exists for {service_request['customer_name']} with truck {service_request['truck_id']}",
                "existing_request": existing_request,
                "new_request": service_request
            }
        else:
            success = self.save_service_request(service_request)
            if success:
                self.processed_requests.add(request_key)
                return {"status": "saved", "message": "Request saved successfully", "request": service_request}
            else:
                return {"status": "save_error", "message": "Failed to save request"}
    
    def close_connection(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
    
    def get_last_saved_id(self) -> Optional[str]:
        """
        Get the ID of the last saved document.
        
        Returns:
            Optional[str]: The last saved document ID or None
        """
        return self.last_saved_id
    
    def clear_processed_requests(self):
        """Clear the processed requests set (useful for new sessions)."""
        self.processed_requests.clear()


def create_mongodb_service() -> MongoDBService:
    """
    Factory function to create a new MongoDB service instance.
    
    Returns:
        MongoDBService: A new MongoDB service instance
    """
    return MongoDBService()
