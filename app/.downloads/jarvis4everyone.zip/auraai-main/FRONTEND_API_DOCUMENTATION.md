# Frontend API Documentation - Requests Page

## Overview
This document describes how the backend sends data for the requests page, including the data structure, field types, and how to handle the new schema format.

## API Endpoint
```
GET /api/requests?limit=100&skip=0
```

## Response Structure
The backend returns a JSON response with the following structure:

```json
{
  "success": true,
  "requests": [
    // Array of request objects (see below)
  ],
  "total_count": 3,
  "returned_count": 3,
  "limit": 100,
  "skip": 0,
  "status_filter": null,
  "timestamp": "2025-01-21T16:22:53.123456"
}
```

## Individual Request Object Structure

Each request object in the `requests` array has the following structure:

```json
{
  "_id": "68f75c6d04544db33e08d5d3",
  "status": "approved",
  "customer_name": "Rohit",
  "contact_number": "9090901234",
  "truck_id": "DL-09-AB",
  "truck_company_name": "Tata",
  "service_type": [
    {
      "name": "Truck Wash",
      "service_status": "pending"
    },
    {
      "name": "Standard Oil Change",
      "service_status": "pending"
    },
    {
      "name": "Engine Tune-ups",
      "service_status": "done"
    }
  ],
  "priority": "urgent",
  "created_at": "2025-10-21T10:11:57.177Z",
  "updated_at": "2025-10-21T15:47:42.304Z",
  "notes": "No notes.",
  "created_by": "auraai",
  "source": "aiassistantaura",
  "auto_approved": false,
  "assigned_worker_employee_id": "003",
  "assigned_worker_id": "68f745bae570c0134c22ea33",
  "assigned_worker_name": "Karan",
  "updated_by": "admin"
}
```

## Field Descriptions

### Core Fields (Always Present)
| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `_id` | String | Unique identifier for the request | `"68f75c6d04544db33e08d5d3"` |
| `status` | String | Current status of the request | `"requested"`, `"approved"`, `"completed"` |
| `customer_name` | String | Full name of the customer | `"Rohit"` |
| `contact_number` | String | Customer's contact number | `"9090901234"` |
| `truck_id` | String | Truck identifier | `"DL-09-AB"` |
| `truck_company_name` | String | Truck manufacturer name | `"Tata"` |
| `service_type` | Array of Objects | List of services requested | See Service Type section below |
| `priority` | String | Urgency level | `"emergency"`, `"urgent"`, `"normal"` |
| `created_at` | String | Creation timestamp (ISO 8601) | `"2025-10-21T10:11:57.177Z"` |
| `updated_at` | String | Last update timestamp (ISO 8601) | `"2025-10-21T15:47:42.304Z"` |
| `notes` | String | Additional notes | `"No notes."` |
| `created_by` | String | Entity that created the request | `"auraai"` |
| `source` | String | Source system | `"aiassistantaura"` |
| `auto_approved` | Boolean | Whether request was auto-approved | `false` |

### Optional Fields (May Not Be Present)
| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `assigned_worker_employee_id` | String | Employee ID of assigned worker | `"003"` |
| `assigned_worker_id` | String | MongoDB ID of assigned worker | `"68f745bae570c0134c22ea33"` |
| `assigned_worker_name` | String | Name of assigned worker | `"Karan"` |
| `updated_by` | String | User who last updated the request | `"admin"` |

## Service Type Structure (IMPORTANT CHANGE)

The `service_type` field has changed from a simple array of strings to an array of objects. Each service object contains:

```json
{
  "name": "Truck Wash",
  "service_status": "pending"
}
```

### Service Object Fields
| Field | Type | Description | Possible Values |
|-------|------|-------------|-----------------|
| `name` | String | Name of the service | `"Truck Wash"`, `"Standard Oil Change"`, etc. |
| `service_status` | String | Status of this specific service | `"pending"`, `"done"`, `"in_progress"` |

## Frontend Implementation Guide

### 1. Displaying Service Types
**Current Issue**: The UI shows `[object Object]` because it's receiving objects instead of strings.

**Solution**: Iterate through the service_type array and extract the `name` field:

```javascript
// Instead of displaying service_type directly
const serviceNames = request.service_type.map(service => service.name).join(', ');
// Result: "Truck Wash, Standard Oil Change, Engine Tune-ups"

// Or display each service with its status
request.service_type.forEach(service => {
  console.log(`${service.name}: ${service.service_status}`);
});
```

### 2. Handling Optional Fields
Always check if optional fields exist before using them:

```javascript
const assignedWorker = request.assigned_worker_name || 'Not Assigned';
const employeeId = request.assigned_worker_employee_id || 'N/A';
```

### 3. Date Formatting
The backend sends dates in ISO 8601 format. You can parse and format them:

```javascript
const createdDate = new Date(request.created_at);
const formattedDate = createdDate.toLocaleDateString();
```

### 4. Status Mapping
Map backend status values to display-friendly text:

```javascript
const statusMap = {
  'requested': 'Requested',
  'approved': 'Approved',
  'completed': 'Completed',
  'in_progress': 'In Progress'
};
const displayStatus = statusMap[request.status] || request.status;
```

### 5. Priority Styling
Use priority values for conditional styling:

```javascript
const getPriorityClass = (priority) => {
  switch(priority.toLowerCase()) {
    case 'emergency': return 'priority-emergency';
    case 'urgent': return 'priority-urgent';
    case 'normal': return 'priority-normal';
    default: return 'priority-default';
  }
};
```

## Error Handling

The backend may return error responses:

```json
{
  "error": "MongoDB service not available",
  "requests": [],
  "total_count": 0,
  "limit": 100,
  "skip": 0
}
```

Always check for the `error` field and handle it appropriately.

## Future-Proof Design

The backend is designed to be future-proof. If new fields are added to the MongoDB schema, they will be included in the JSON response. The frontend should:

1. **Only extract fields you need** - ignore unknown fields
2. **Use optional chaining** - `request.newField?.value`
3. **Provide fallbacks** - `request.newField || 'Default Value'`

## Example Frontend Code

```javascript
// Fetch requests
const fetchRequests = async () => {
  try {
    const response = await fetch('/api/requests?limit=100&skip=0');
    const data = await response.json();
    
    if (data.error) {
      console.error('Error:', data.error);
      return;
    }
    
    // Process each request
    data.requests.forEach(request => {
      // Extract service names
      const serviceNames = request.service_type
        .map(service => service.name)
        .join(', ');
      
      // Handle optional fields
      const assignedWorker = request.assigned_worker_name || 'Not Assigned';
      
      // Format date
      const createdDate = new Date(request.created_at).toLocaleDateString();
      
      // Create request card
      const requestCard = {
        id: request._id,
        customerName: request.customer_name,
        truckId: request.truck_id,
        company: request.truck_company_name,
        services: serviceNames,
        priority: request.priority,
        status: request.status,
        assignedWorker: assignedWorker,
        createdAt: createdDate
      };
      
      // Render the card
      renderRequestCard(requestCard);
    });
  } catch (error) {
    console.error('Failed to fetch requests:', error);
  }
};
```

## Migration Notes

If you have existing code that expects `service_type` to be an array of strings, you'll need to update it to handle the new object structure. The old format is no longer supported.

## Support

If you encounter any issues with the API or need clarification on any field, please contact the backend team.
