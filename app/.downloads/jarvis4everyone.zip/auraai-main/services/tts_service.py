"""
Text-to-Speech Service using OpenAI TTS and EdgeTTS
Provides audio generation with OpenAI cedar voice as default
"""

import asyncio
import io
import tempfile
import os
from typing import Optional
import edge_tts
from openai import AsyncOpenAI
from utils.logger import logger

class TTSService:
    """Text-to-Speech service using OpenAI TTS and Microsoft Edge TTS."""
    
    def __init__(self, voice: str = "ash", provider: str = "openai"):
        """
        Initialize TTS service.
        
        Args:
            voice (str): Voice to use for TTS (default: ash for OpenAI male voice, en-CA-LiamNeural for EdgeTTS)
            provider (str): TTS provider to use ("openai" or "edgetts")
        """
        self.voice = voice
        self.provider = provider
        self.rate = "+20%"  # Speech rate (120% speed by default) - EdgeTTS only
        self.pitch = "+0Hz"  # Speech pitch - EdgeTTS only
        self.volume = "+0%"  # Speech volume - EdgeTTS only
        
        logger.info(f"🔍 DEBUG: TTS Service initialized with voice: '{self.voice}' and provider: '{self.provider}'")
        
        # Initialize OpenAI client if using OpenAI TTS
        if self.provider == "openai":
            self.openai_client = AsyncOpenAI(
                api_key=os.getenv("OPENAI_API_KEY", "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")
            )
        
    async def text_to_speech(self, text: str, output_format: str = "mp3") -> bytes:
        """
        Convert text to speech and return audio bytes.
        
        Args:
            text (str): Text to convert to speech
            output_format (str): Output format (mp3, wav, etc.)
            
        Returns:
            bytes: Audio file bytes
            
        Raises:
            Exception: If TTS conversion fails
        """
        try:
            if not text or not text.strip():
                raise ValueError("Text cannot be empty")
            
            # Limit text length to prevent very long audio files (optimized for faster processing)
            if len(text) > 1500:
                text = text[:1500] + "..."
                logger.warning(f"Text truncated to 1500 characters for faster TTS processing")
            
            logger.info(f"🎤 Converting text to speech using {self.provider}: '{text[:50]}...'")
            
            if self.provider == "openai":
                return await self._openai_text_to_speech(text, output_format)
            else:
                return await self._edgetts_text_to_speech(text, output_format)
            
        except Exception as e:
            logger.error(f"❌ TTS conversion failed: {str(e)}")
            raise Exception(f"TTS conversion failed: {str(e)}")
    
    async def _openai_text_to_speech(self, text: str, output_format: str) -> bytes:
        """Convert text to speech using OpenAI TTS."""
        try:
            logger.info(f"🔍 DEBUG: OpenAI TTS using voice: '{self.voice}' for text: '{text[:30]}...'")
            
            response = await self.openai_client.audio.speech.create(
                model="tts-1",  # Faster model for quicker response
                voice=self.voice,
                input=text,
                response_format=output_format
            )
            
            audio_data = response.content
            logger.success(f"✅ OpenAI TTS conversion completed: {len(audio_data)} bytes")
            return audio_data
            
        except Exception as e:
            # If the voice is not available, try with a fallback voice
            if "Input should be" in str(e) and self.voice not in ["alloy", "echo", "fable", "onyx", "nova", "shimmer", "coral", "ash", "sage"]:
                logger.warning(f"Voice '{self.voice}' not available, trying with 'ash' as fallback")
                fallback_voice = "ash"
                try:
                    response = await self.openai_client.audio.speech.create(
                        model="tts-1",  # Faster model for quicker response
                        voice=fallback_voice,
                        input=text,
                        response_format=output_format
                    )
                    
                    audio_data = response.content
                    logger.success(f"✅ OpenAI TTS conversion completed with fallback voice '{fallback_voice}': {len(audio_data)} bytes")
                    return audio_data
                except Exception as fallback_e:
                    logger.error(f"❌ OpenAI TTS conversion failed even with fallback: {str(fallback_e)}")
                    raise Exception(f"OpenAI TTS conversion failed: {str(fallback_e)}")
            else:
                logger.error(f"❌ OpenAI TTS conversion failed: {str(e)}")
                raise Exception(f"OpenAI TTS conversion failed: {str(e)}")
    
    async def _edgetts_text_to_speech(self, text: str, output_format: str) -> bytes:
        """Convert text to speech using EdgeTTS."""
        try:
            # Create TTS communication
            communicate = edge_tts.Communicate(
                text=text,
                voice=self.voice,
                rate=self.rate,
                pitch=self.pitch,
                volume=self.volume
            )
            
            # Generate audio
            audio_data = b""
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio_data += chunk["data"]
            
            logger.success(f"✅ EdgeTTS conversion completed: {len(audio_data)} bytes")
            return audio_data
            
        except Exception as e:
            logger.error(f"❌ EdgeTTS conversion failed: {str(e)}")
            raise Exception(f"EdgeTTS conversion failed: {str(e)}")
    
    async def text_to_speech_file(self, text: str, output_path: str) -> str:
        """
        Convert text to speech and save to file.
        
        Args:
            text (str): Text to convert to speech
            output_path (str): Path to save the audio file
            
        Returns:
            str: Path to the saved audio file
            
        Raises:
            Exception: If TTS conversion fails
        """
        try:
            if not text or not text.strip():
                raise ValueError("Text cannot be empty")
            
            # Limit text length (optimized for faster processing)
            if len(text) > 1500:
                text = text[:1500] + "..."
                logger.warning(f"Text truncated to 1500 characters for faster TTS processing")
            
            logger.info(f"🎤 Converting text to speech file using {self.provider}: '{text[:50]}...'")
            
            if self.provider == "openai":
                return await self._openai_text_to_speech_file(text, output_path)
            else:
                return await self._edgetts_text_to_speech_file(text, output_path)
            
        except Exception as e:
            logger.error(f"❌ TTS file conversion failed: {str(e)}")
            raise Exception(f"TTS file conversion failed: {str(e)}")
    
    async def _openai_text_to_speech_file(self, text: str, output_path: str) -> str:
        """Convert text to speech using OpenAI TTS and save to file."""
        try:
            # Get file extension from output path
            file_ext = os.path.splitext(output_path)[1].lstrip('.')
            if not file_ext:
                file_ext = "mp3"
            
            response = await self.openai_client.audio.speech.create(
                model="tts-1",  # Faster model for quicker response
                voice=self.voice,
                input=text,
                response_format=file_ext
            )
            
            # Save audio data to file
            with open(output_path, 'wb') as f:
                f.write(response.content)
            
            logger.success(f"✅ OpenAI TTS file saved: {output_path}")
            return output_path
            
        except Exception as e:
            # If the voice is not available, try with a fallback voice
            if "Input should be" in str(e) and self.voice not in ["alloy", "echo", "fable", "onyx", "nova", "shimmer", "coral", "ash", "sage"]:
                logger.warning(f"Voice '{self.voice}' not available for file save, trying with 'ash' as fallback")
                fallback_voice = "ash"
                try:
                    # Get file extension from output path
                    file_ext = os.path.splitext(output_path)[1].lstrip('.')
                    if not file_ext:
                        file_ext = "mp3"
                    
                    response = await self.openai_client.audio.speech.create(
                        model="tts-1",  # Faster model for quicker response
                        voice=fallback_voice,
                        input=text,
                        response_format=file_ext
                    )
                    
                    # Save audio data to file
                    with open(output_path, 'wb') as f:
                        f.write(response.content)
                    
                    logger.success(f"✅ OpenAI TTS file saved with fallback voice '{fallback_voice}': {output_path}")
                    return output_path
                except Exception as fallback_e:
                    logger.error(f"❌ OpenAI TTS file conversion failed even with fallback: {str(fallback_e)}")
                    raise Exception(f"OpenAI TTS file conversion failed: {str(fallback_e)}")
            else:
                logger.error(f"❌ OpenAI TTS file conversion failed: {str(e)}")
                raise Exception(f"OpenAI TTS file conversion failed: {str(e)}")
    
    async def _edgetts_text_to_speech_file(self, text: str, output_path: str) -> str:
        """Convert text to speech using EdgeTTS and save to file."""
        try:
            # Create TTS communication
            communicate = edge_tts.Communicate(
                text=text,
                voice=self.voice,
                rate=self.rate,
                pitch=self.pitch,
                volume=self.volume
            )
            
            # Save to file
            await communicate.save(output_path)
            
            logger.success(f"✅ EdgeTTS file saved: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"❌ EdgeTTS file conversion failed: {str(e)}")
            raise Exception(f"EdgeTTS file conversion failed: {str(e)}")
    
    def get_available_voices(self) -> list:
        """
        Get list of available voices.
        
        Returns:
            list: List of available voice names
        """
        try:
            if self.provider == "openai":
                return ["alloy", "echo", "fable", "onyx", "nova", "shimmer", "coral", "ash", "sage"]
            else:
                voices = edge_tts.list_voices()
                return [voice["ShortName"] for voice in voices]
        except Exception as e:
            logger.error(f"❌ Failed to get available voices: {str(e)}")
            return []
    
    def get_voice_info(self) -> dict:
        """
        Get information about the current voice.
        
        Returns:
            dict: Voice information
        """
        if self.provider == "openai":
            return {
                "voice": self.voice,
                "provider": self.provider,
                "description": "OpenAI TTS Male Voice - Helpful and friendly tone with excitement and enthusiasm",
                "available_voices": ["alloy", "echo", "fable", "onyx", "nova", "shimmer", "coral", "ash", "sage"]
            }
        else:
            return {
                "voice": self.voice,
                "provider": self.provider,
                "rate": self.rate,
                "pitch": self.pitch,
                "volume": self.volume,
                "description": "Canadian English Male Voice"
            }
    
    def set_voice_settings(self, rate: Optional[str] = None, pitch: Optional[str] = None, volume: Optional[str] = None):
        """
        Update voice settings (EdgeTTS only).
        
        Args:
            rate (str, optional): Speech rate (e.g., "+10%", "-5%")
            pitch (str, optional): Speech pitch (e.g., "+50Hz", "-20Hz")
            volume (str, optional): Speech volume (e.g., "+10%", "-5%")
        """
        if self.provider != "edgetts":
            logger.warning("Voice settings (rate, pitch, volume) are only available for EdgeTTS provider")
            return
            
        if rate is not None:
            self.rate = rate
        if pitch is not None:
            self.pitch = pitch
        if volume is not None:
            self.volume = volume
        
        logger.info(f"🎛️ Voice settings updated: rate={self.rate}, pitch={self.pitch}, volume={self.volume}")
    
    def set_provider(self, provider: str, voice: Optional[str] = None):
        """
        Switch TTS provider.
        
        Args:
            provider (str): TTS provider to use ("openai" or "edgetts")
            voice (str, optional): Voice to use with the new provider
        """
        if provider not in ["openai", "edgetts"]:
            raise ValueError("Provider must be 'openai' or 'edgetts'")
        
        self.provider = provider
        
        if voice:
            self.voice = voice
        elif provider == "openai" and self.voice not in ["alloy", "echo", "fable", "onyx", "nova", "shimmer", "coral", "ash", "sage"]:
            self.voice = "ash"  # Default OpenAI male voice
        elif provider == "edgetts" and not self.voice.startswith("en-"):
            self.voice = "en-CA-LiamNeural"  # Default EdgeTTS voice
        
        # Initialize OpenAI client if switching to OpenAI
        if self.provider == "openai" and not hasattr(self, 'openai_client'):
            self.openai_client = AsyncOpenAI(
                api_key=os.getenv("OPENAI_API_KEY", "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")
            )
        
        logger.info(f"🔄 TTS provider switched to {self.provider} with voice {self.voice}")
    
    async def fast_text_to_speech(self, text: str, output_format: str = "mp3") -> bytes:
        """
        Fast TTS conversion optimized for quick response.
        Uses shorter text limits and faster processing.
        """
        try:
            if not text or not text.strip():
                raise ValueError("Text cannot be empty")
            
            # Shorter text limit for faster processing
            if len(text) > 1000:
                text = text[:1000] + "..."
                logger.warning(f"Text truncated to 1000 characters for fast TTS")
            
            logger.info(f"⚡ Fast TTS conversion: '{text[:30]}...'")
            
            if self.provider == "openai":
                return await self._openai_fast_text_to_speech(text, output_format)
            else:
                return await self._edgetts_text_to_speech(text, output_format)
            
        except Exception as e:
            logger.error(f"❌ Fast TTS conversion failed: {str(e)}")
            raise Exception(f"Fast TTS conversion failed: {str(e)}")
    
    async def _openai_fast_text_to_speech(self, text: str, output_format: str) -> bytes:
        """Fast OpenAI TTS conversion with optimized settings."""
        try:
            logger.info(f"🔍 DEBUG: Fast OpenAI TTS using voice: '{self.voice}' for text: '{text[:30]}...'")
            
            # Use the same model as regular TTS but with optimized settings
            response = await self.openai_client.audio.speech.create(
                model="tts-1",  # Same as regular for consistency
                voice=self.voice,
                input=text,
                response_format=output_format
            )
            
            audio_data = response.content
            logger.success(f"⚡ Fast OpenAI TTS completed: {len(audio_data)} bytes")
            return audio_data
            
        except Exception as e:
            logger.error(f"❌ Fast OpenAI TTS failed: {str(e)}")
            raise Exception(f"Fast OpenAI TTS failed: {str(e)}")
    
    def set_voice(self, voice: str):
        """
        Set the voice for TTS.
        
        Args:
            voice (str): Voice to use for TTS
        """
        old_voice = self.voice
        self.voice = voice
        logger.info(f"🎤 Voice updated from '{old_voice}' to '{voice}'")
        logger.info(f"🔍 DEBUG: TTS Service voice is now: {self.voice}")
    
    def set_cedar_voice(self):
        """
        Set cedar voice with automatic fallback to ash (male voice) if cedar is not available.
        This method will attempt to use cedar voice, but will fallback to ash if cedar is not supported.
        """
        self.voice = "cedar"
        logger.info("🎤 Cedar voice set (will fallback to ash male voice if not available)")
    
    def set_male_voice(self):
        """
        Set a male voice (ash) as the default.
        """
        self.voice = "ash"
        logger.info("🎤 Male voice (ash) set as default")

# Global TTS service instance with OpenAI ash male voice as default
tts_service = TTSService(voice="ash", provider="openai")
