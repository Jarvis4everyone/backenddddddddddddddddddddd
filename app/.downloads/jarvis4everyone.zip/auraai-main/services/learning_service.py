"""
Learning Service - Wrapper for the LearningManager to make it async-compatible.
"""

from typing import Optional
from Data.LearningManager import LearningManager

class LearningService:
    """Service for managing learning data and knowledge base."""
    
    def __init__(self):
        """Initialize the learning service."""
        self.learning_manager = None
        self._initialize_learning_manager()
    
    def _initialize_learning_manager(self):
        """Initialize the learning manager."""
        try:
            self.learning_manager = LearningManager()
        except Exception as e:
            print(f"⚠️ Warning: Learning Manager initialization failed: {str(e)}")
            self.learning_manager = None
    
    async def get_context_for_query(self, query: str) -> Optional[str]:
        """Get context for a query (async wrapper)."""
        if not self.learning_manager:
            return None
        
        try:
            # Run the synchronous method in a thread pool
            import asyncio
            loop = asyncio.get_event_loop()
            context = await loop.run_in_executor(
                None, 
                self.learning_manager.get_context_for_query, 
                query
            )
            return context
        except Exception as e:
            print(f"⚠️ Warning: Error getting context: {str(e)}")
            return None
    
    def is_available(self) -> bool:
        """Check if the learning service is available."""
        return self.learning_manager is not None
