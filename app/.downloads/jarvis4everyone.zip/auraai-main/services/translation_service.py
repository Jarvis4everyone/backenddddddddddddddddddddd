"""
Translation Service for AURA Backend
Handles translation between different languages and English for LLM processing.
Uses mtranslate for reliable translation without API keys.
"""

import os
import asyncio
from typing import Optional, Dict, Any
from mtranslate import translate
from utils.logger import logger

class TranslationService:
    """
    Service for handling language translation.
    Translates user input to English for LLM processing,
    then translates LLM response back to user's language.
    """
    
    def __init__(self):
        """Initialize the translation service."""
        try:
            # mtranslate doesn't need initialization, it's a simple function
            self.supported_languages = {
                "en-US": "en",
                "en-GB": "en", 
                "hi-IN": "hi",
                "pa-IN": "pa",
                "ru-RU": "ru"
            }
            
            logger.info("🌐 Translation Service initialized with mtranslate")
        except Exception as e:
            logger.error(f"❌ Translation Service initialization failed: {str(e)}")
            self.supported_languages = {"en-US": "en", "en-GB": "en"}
    
    def is_english(self, language_code: str) -> bool:
        """
        Check if the language code represents English.
        
        Args:
            language_code: Language code (e.g., "en-US", "hi-IN")
            
        Returns:
            bool: True if English, False otherwise
        """
        return language_code.startswith("en")
    
    def get_mtranslate_language_code(self, language_code: str) -> str:
        """
        Convert language code to mtranslate format.
        
        Args:
            language_code: Language code (e.g., "en-US", "hi-IN")
            
        Returns:
            str: mtranslate language code
        """
        return self.supported_languages.get(language_code, "en")
    
    async def translate_to_english(self, text: str, source_language: str) -> Dict[str, Any]:
        """
        Translate text from source language to English.
        
        Args:
            text: Text to translate
            source_language: Source language code
            
        Returns:
            Dict containing translated text and metadata
        """
        try:
            # If already English, return as-is
            if self.is_english(source_language):
                return {
                    "translated_text": text,
                    "original_text": text,
                    "source_language": source_language,
                    "target_language": "en",
                    "translation_needed": False,
                    "confidence": 1.0
                }
            
            # Translate to English
            mtranslate_source = self.get_mtranslate_language_code(source_language)
            
            logger.info(f"🔄 Translating from {source_language} ({mtranslate_source}) to English: '{text[:50]}...'")
            
            # Use asyncio.to_thread for non-blocking translation
            translated_text = await asyncio.to_thread(
                translate,
                text,
                "en",
                mtranslate_source
            )
            
            logger.success(f"✅ Translation completed: '{translated_text[:50]}...'")
            
            return {
                "translated_text": translated_text,
                "original_text": text,
                "source_language": source_language,
                "target_language": "en",
                "translation_needed": True,
                "confidence": 0.9  # mtranslate doesn't provide confidence scores
            }
            
        except Exception as e:
            logger.error(f"❌ Translation to English failed: {str(e)}")
            # Return original text if translation fails
            return {
                "translated_text": text,
                "original_text": text,
                "source_language": source_language,
                "target_language": "en",
                "translation_needed": False,
                "error": str(e),
                "confidence": 0.0
            }
    
    async def translate_from_english(self, text: str, target_language: str) -> Dict[str, Any]:
        """
        Translate text from English to target language.
        
        Args:
            text: English text to translate
            target_language: Target language code
            
        Returns:
            Dict containing translated text and metadata
        """
        try:
            # If target is English, return as-is
            if self.is_english(target_language):
                return {
                    "translated_text": text,
                    "original_text": text,
                    "source_language": "en",
                    "target_language": target_language,
                    "translation_needed": False,
                    "confidence": 1.0
                }
            
            # Translate from English to target language
            mtranslate_target = self.get_mtranslate_language_code(target_language)
            
            logger.info(f"🔄 Translating from English to {target_language} ({mtranslate_target}): '{text[:50]}...'")
            
            # Use asyncio.to_thread for non-blocking translation
            translated_text = await asyncio.to_thread(
                translate,
                text,
                mtranslate_target,
                "en"
            )
            
            logger.success(f"✅ Translation completed: '{translated_text[:50]}...'")
            
            return {
                "translated_text": translated_text,
                "original_text": text,
                "source_language": "en",
                "target_language": target_language,
                "translation_needed": True,
                "confidence": 0.9  # mtranslate doesn't provide confidence scores
            }
            
        except Exception as e:
            logger.error(f"❌ Translation from English failed: {str(e)}")
            # Return original text if translation fails
            return {
                "translated_text": text,
                "original_text": text,
                "source_language": "en",
                "target_language": target_language,
                "translation_needed": False,
                "error": str(e),
                "confidence": 0.0
            }
    
    async def translate_message(self, text: str, source_language: str, target_language: str) -> Dict[str, Any]:
        """
        Translate message between any two supported languages.
        
        Args:
            text: Text to translate
            source_language: Source language code
            target_language: Target language code
            
        Returns:
            Dict containing translated text and metadata
        """
        try:
            # If same language, return as-is
            if source_language == target_language:
                return {
                    "translated_text": text,
                    "original_text": text,
                    "source_language": source_language,
                    "target_language": target_language,
                    "translation_needed": False,
                    "confidence": 1.0
                }
            
            google_source = self.get_google_language_code(source_language)
            google_target = self.get_google_language_code(target_language)
            
            logger.info(f"🔄 Translating from {source_language} ({google_source}) to {target_language} ({google_target}): '{text[:50]}...'")
            
            # Check if translator is available
            if not self.translator:
                raise Exception("Translation service not available")
            
            # Use asyncio.to_thread for non-blocking translation
            result = await asyncio.to_thread(
                self.translator.translate,
                text,
                src=google_source,
                dest=google_target
            )
            
            translated_text = result.text
            
            logger.success(f"✅ Translation completed: '{translated_text[:50]}...'")
            
            return {
                "translated_text": translated_text,
                "original_text": text,
                "source_language": source_language,
                "target_language": target_language,
                "translation_needed": True,
                "confidence": getattr(result, 'confidence', 0.9)
            }
            
        except Exception as e:
            logger.error(f"❌ Translation failed: {str(e)}")
            # Return original text if translation fails
            return {
                "translated_text": text,
                "original_text": text,
                "source_language": source_language,
                "target_language": target_language,
                "translation_needed": False,
                "error": str(e),
                "confidence": 0.0
            }
    
    def get_supported_languages(self) -> Dict[str, str]:
        """
        Get list of supported languages.
        
        Returns:
            Dict mapping language codes to language names
        """
        return {
            "en-US": "English (US)",
            "en-GB": "English (UK)",
            "hi-IN": "Hindi (India)",
            "pa-IN": "Punjabi (India)",
            "ru-RU": "Russian (Russia)"
        }
    
    def validate_language(self, language_code: str) -> bool:
        """
        Validate if language code is supported.
        
        Args:
            language_code: Language code to validate
            
        Returns:
            bool: True if supported, False otherwise
        """
        return language_code in self.supported_languages

# Global translation service instance
translation_service = None

def get_translation_service():
    """Get the global translation service instance, creating it if needed."""
    global translation_service
    if translation_service is None:
        translation_service = TranslationService()
    return translation_service
