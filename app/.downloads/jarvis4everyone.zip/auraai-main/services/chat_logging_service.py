"""
Chat Logging Service - Handles saving chat conversations to MongoDB.
"""

import os
from datetime import datetime
from typing import Dict, List, Optional, Any
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from dotenv import load_dotenv

load_dotenv()

class ChatLoggingService:
    """Service for logging chat conversations to MongoDB."""
    
    def __init__(self):
        """Initialize the chat logging service."""
        self.mongodb_url = os.getenv("MongoDB_URL")
        if not self.mongodb_url:
            raise ValueError("MongoDB_URL not found in environment variables")
        
        self.mongodb_client = None
        self.db = None
        self.chats_collection = None
        self._connect_to_mongodb()
    
    def _connect_to_mongodb(self):
        """Connect to MongoDB database."""
        try:
            self.mongodb_client = MongoClient(
                self.mongodb_url, 
                serverSelectionTimeoutMS=5000,
                retryWrites=True,
                w='majority'
            )
            self.db = self.mongodb_client.aura
            self.chats_collection = self.db.chats
            
            # Test connection
            self.mongodb_client.admin.command('ping')
            
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            print(f"❌ Failed to connect to MongoDB for chat logging: {str(e)}")
            raise
    
    def create_chat_session(self, session_id: str, chatbot_type: str) -> str:
        """
        Create a new chat session document.
        
        Args:
            session_id: Unique session identifier
            chatbot_type: Type of chatbot ('general_chatbot' or 'modify_chatbot')
            
        Returns:
            str: Document ID of the created session
        """
        try:
            chat_document = {
                "session_id": session_id,
                "chatbot_type": chatbot_type,
                "status": "active",
                "created_at": datetime.now(),
                "updated_at": datetime.now(),
                "messages": [],
                "message_count": 0,
                "last_activity": datetime.now()
            }
            
            result = self.chats_collection.insert_one(chat_document)
            return str(result.inserted_id)
            
        except Exception as e:
            print(f"❌ Error creating chat session: {str(e)}")
            raise
    
    def add_message_pair(self, session_id: str, user_message: str, assistant_message: str, chatbot_type: str, input_language: str = "en-US", voice: str = "alloy", pending_messages: list = None) -> bool:
        """
        Add a user-assistant message pair to the chat session with language and voice context.
        Creates the MongoDB session if it doesn't exist (first message pair) and includes any pending messages.
        
        Args:
            session_id: Session identifier
            user_message: User's message
            assistant_message: Assistant's response
            chatbot_type: Current chatbot type
            input_language: User's language preference
            voice: User's voice preference
            pending_messages: List of messages stored in memory before MongoDB session creation
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Check if session exists in MongoDB
            existing_session = self.chats_collection.find_one({"session_id": session_id})
            
            if not existing_session:
                # Create the session in MongoDB on first message pair
                self.create_chat_session(session_id, chatbot_type)
                print(f"📝 Created MongoDB session {session_id} on first assistant response")
                
                # Add any pending messages (like welcome messages) to the new session
                if pending_messages:
                    print(f"📝 Adding {len(pending_messages)} pending messages to MongoDB session")
                    for pending_msg in pending_messages:
                        self.chats_collection.update_one(
                            {"session_id": session_id},
                            {
                                "$push": {"messages": pending_msg},
                                "$inc": {"message_count": 1}
                            }
                        )
            
            message_pair = {
                "user_message": user_message,
                "assistant_message": assistant_message,
                "chatbot_type": chatbot_type,
                "input_language": input_language,
                "voice": voice,
                "timestamp": datetime.now()
            }
            
            # Update the document with the new message pair
            result = self.chats_collection.update_one(
                {"session_id": session_id},
                {
                    "$push": {"messages": message_pair},
                    "$inc": {"message_count": 1},
                    "$set": {
                        "updated_at": datetime.now(),
                        "last_activity": datetime.now(),
                        "chatbot_type": chatbot_type,  # Update current chatbot type
                        "input_language": input_language,  # Update language preference
                        "voice": voice  # Update voice preference
                    }
                }
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"❌ Error adding message pair: {str(e)}")
            return False
    
    def update_chatbot_type(self, session_id: str, new_chatbot_type: str) -> bool:
        """
        Update the chatbot type for a session (for redirections).
        
        Args:
            session_id: Session identifier
            new_chatbot_type: New chatbot type
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            result = self.chats_collection.update_one(
                {"session_id": session_id},
                {
                    "$set": {
                        "chatbot_type": new_chatbot_type,
                        "updated_at": datetime.now(),
                        "last_activity": datetime.now()
                    }
                }
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"❌ Error updating chatbot type: {str(e)}")
            return False
    
    def end_chat_session(self, session_id: str) -> bool:
        """
        Mark a chat session as ended.
        
        Args:
            session_id: Session identifier
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            result = self.chats_collection.update_one(
                {"session_id": session_id},
                {
                    "$set": {
                        "status": "ended",
                        "ended_at": datetime.now(),
                        "updated_at": datetime.now()
                    }
                }
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"❌ Error ending chat session: {str(e)}")
            return False
    
    def get_chat_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a chat session by session ID.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Dict containing session data or None if not found
        """
        try:
            return self.chats_collection.find_one({"session_id": session_id})
        except Exception as e:
            print(f"❌ Error getting chat session: {str(e)}")
            return None
    
    def get_chats_by_type(self, chatbot_type: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get chat sessions by chatbot type.
        
        Args:
            chatbot_type: Type of chatbot to filter by
            limit: Maximum number of results
            
        Returns:
            List of chat sessions
        """
        try:
            cursor = self.chats_collection.find(
                {"chatbot_type": chatbot_type}
            ).sort("created_at", -1).limit(limit)
            
            return list(cursor)
        except Exception as e:
            print(f"❌ Error getting chats by type: {str(e)}")
            return []
    
    def get_recent_chats(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get recent chat sessions.
        
        Args:
            limit: Maximum number of results
            
        Returns:
            List of recent chat sessions
        """
        try:
            cursor = self.chats_collection.find().sort("created_at", -1).limit(limit)
            return list(cursor)
        except Exception as e:
            print(f"❌ Error getting recent chats: {str(e)}")
            return []
    
    def close_connection(self):
        """Close MongoDB connection."""
        if self.mongodb_client:
            self.mongodb_client.close()
