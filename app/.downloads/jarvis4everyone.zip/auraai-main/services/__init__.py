"""
Chat Service - Handles all chatbot interactions and session management.
"""

import asyncio
import uuid
from typing import Dict, Any, Optional
from datetime import datetime

# Import our existing chatbot modules
from Chatbot.Chatbot import Chatbot
from Modify.Chatbot import ModifyChatbot
from services.learning_service import LearningService

class ChatService:
    """Service for managing chatbot interactions."""
    
    def __init__(self, learning_service: Optional[LearningService] = None):
        """Initialize the chat service."""
        self.learning_service = learning_service
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.regular_chatbot = None
        self.modify_chatbot = None
        
        # Initialize chatbots
        self._initialize_chatbots()
    
    def _initialize_chatbots(self):
        """Initialize chatbot instances."""
        try:
            # Create regular chatbot
            self.regular_chatbot = Chatbot(shared_learning_manager=self.learning_service)
            
            # Create modify chatbot
            self.modify_chatbot = ModifyChatbot(shared_learning_manager=self.learning_service)
            
        except Exception as e:
            print(f"❌ Error initializing chatbots: {str(e)}")
            raise e
    
    async def create_session(self) -> str:
        """Create a new chat session."""
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {
            "created_at": datetime.now(),
            "current_chatbot": "regular",
            "message_count": 0,
            "last_activity": datetime.now()
        }
        return session_id
    
    async def get_regular_response(self, message: str, session_id: str) -> Dict[str, Any]:
        """Get response from regular chatbot."""
        if not self.regular_chatbot:
            raise Exception("Regular chatbot not initialized")
        
        # Update session
        if session_id in self.sessions:
            self.sessions[session_id]["message_count"] += 1
            self.sessions[session_id]["last_activity"] = datetime.now()
        
        # Get response
        response = self.regular_chatbot.get_response(message)
        
        # Check for redirect
        redirect = "[ Processing Redirect ]" in response
        
        return {
            "response": response,
            "redirect": redirect,
            "session_id": session_id
        }
    
    async def get_modify_response(self, message: str, session_id: str) -> Dict[str, Any]:
        """Get response from modify chatbot."""
        if not self.modify_chatbot:
            raise Exception("Modify chatbot not initialized")
        
        # Update session
        if session_id in self.sessions:
            self.sessions[session_id]["message_count"] += 1
            self.sessions[session_id]["last_activity"] = datetime.now()
        
        # Get response
        response = self.modify_chatbot.get_response(message)
        
        # Check for redirect
        redirect = "[ Processing Redirect ]" in response
        
        return {
            "response": response,
            "redirect": redirect,
            "session_id": session_id
        }
    
    async def cleanup(self):
        """Cleanup resources."""
        try:
            if self.regular_chatbot and hasattr(self.regular_chatbot, 'close_mongodb_connection'):
                self.regular_chatbot.close_mongodb_connection()
            
            if self.modify_chatbot and hasattr(self.modify_chatbot, 'close_mongodb_connection'):
                self.modify_chatbot.close_mongodb_connection()
                
        except Exception as e:
            print(f"⚠️ Warning during cleanup: {str(e)}")
    
    def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session information."""
        return self.sessions.get(session_id)
    
    def get_all_sessions(self) -> Dict[str, Dict[str, Any]]:
        """Get all active sessions."""
        return self.sessions.copy()
