"""
Chat Service - Handles all chatbot interactions and session management.
"""

import asyncio
import uuid
from typing import Dict, Any, Optional
from datetime import datetime

# Import our existing chatbot modules
from Chatbot.Chatbot import Chatbot
from Modify.Chatbot import ModifyChatbot
from services.learning_service import LearningService
from services.chat_logging_service import ChatLoggingService
from services.translation_service import get_translation_service
from utils.logger import logger

class ChatService:
    """Service for managing chatbot interactions."""
    
    def __init__(self, learning_service: Optional[LearningService] = None):
        """Initialize the chat service."""
        self.learning_service = learning_service
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.regular_chatbot = None
        self.modify_chatbot = None
        
        # Initialize chat logging service
        try:
            self.chat_logging = ChatLoggingService()
        except Exception as e:
            logger.warning(f"Chat logging service initialization failed: {str(e)}")
            self.chat_logging = None
        
        # Initialize chatbots
        self._initialize_chatbots()
    
    def _initialize_chatbots(self):
        """Initialize chatbot instances."""
        try:
            # Create regular chatbot
            learning_manager = self.learning_service.learning_manager if self.learning_service else None
            self.regular_chatbot = Chatbot(shared_learning_manager=learning_manager)
            
            # Create modify chatbot
            self.modify_chatbot = ModifyChatbot(shared_learning_manager=learning_manager)
            
        except Exception as e:
            print(f"❌ Error initializing chatbots: {str(e)}")
            raise e
    
    async def create_session(self, chatbot_type: str = "regular") -> str:
        """Create a new chat session (in memory only, MongoDB session created on first assistant response)."""
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {
            "created_at": datetime.now(),
            "current_chatbot": chatbot_type,
            "message_count": 0,
            "last_activity": datetime.now(),
            "mongodb_session_created": False,  # Track if MongoDB session has been created
            "pending_messages": []  # Store messages until MongoDB session is created
        }
        
        # Don't create MongoDB session immediately - wait for first assistant response
        logger.info(f"📝 Created in-memory session {session_id} for {chatbot_type} chatbot")
        
        return session_id
    
    async def store_welcome_message(self, session_id: str, chatbot_type: str, welcome_message: str) -> bool:
        """Store welcome message in memory until MongoDB session is created."""
        if session_id not in self.sessions:
            return False
        
        welcome_msg = {
            "user_message": "[SYSTEM_WELCOME]",
            "assistant_message": welcome_message,
            "chatbot_type": chatbot_type,
            "input_language": "en-US",
            "voice": "ash",
            "timestamp": datetime.now(),
            "is_welcome": True
        }
        
        self.sessions[session_id]["pending_messages"].append(welcome_msg)
        logger.info(f"📝 Stored welcome message in memory for session {session_id}")
        return True
    
    def _get_regular_chatbot_for_session(self, session_id: str, input_language: str = "en-US"):
        """Get or create a regular chatbot instance for the session (always uses English for LLM processing)."""
        if session_id not in self.sessions:
            return self.regular_chatbot
        
        # Check if we have a session-specific chatbot
        if "regular_chatbot" not in self.sessions[session_id]:
            # Create a new chatbot instance for this session (always English for LLM)
            learning_manager = self.learning_service.learning_manager if self.learning_service else None
            self.sessions[session_id]["regular_chatbot"] = Chatbot(
                shared_learning_manager=learning_manager,
                input_language="en-US"  # Always English for LLM processing
            )
        
        return self.sessions[session_id]["regular_chatbot"]
    
    def _get_modify_chatbot_for_session(self, session_id: str, input_language: str = "en-US"):
        """Get or create a modify chatbot instance for the session (always uses English for LLM processing)."""
        if session_id not in self.sessions:
            return self.modify_chatbot
        
        # Check if we have a session-specific chatbot
        if "modify_chatbot" not in self.sessions[session_id]:
            # Create a new chatbot instance for this session (always English for LLM)
            learning_manager = self.learning_service.learning_manager if self.learning_service else None
            self.sessions[session_id]["modify_chatbot"] = ModifyChatbot(
                shared_learning_manager=learning_manager,
                input_language="en-US"  # Always English for LLM processing
            )
        
        return self.sessions[session_id]["modify_chatbot"]
    
    async def get_regular_response(self, message: str, session_id: str, input_language: str = "en-US", voice: str = "alloy") -> Dict[str, Any]:
        """Get response from regular chatbot with language and voice context."""
        try:
            logger.info(f"🔄 Processing regular chatbot request for session {session_id}")
            logger.info(f"🌐 Language: {input_language}, 🎤 Voice: {voice}")
            
            # Step 1: Translate user message to English if needed
            translation_service = get_translation_service()
            translation_result = await translation_service.translate_to_english(message, input_language)
            english_message = translation_result["translated_text"]
            
            if translation_result["translation_needed"]:
                logger.info(f"🌐 Translated user message to English: '{english_message[:50]}...'")
            else:
                logger.info(f"🌐 User message already in English: '{english_message[:50]}...'")
            
            # Get session-specific chatbot (always use English for LLM processing)
            chatbot = self._get_regular_chatbot_for_session(session_id, "en-US")
            if not chatbot:
                raise Exception("Regular chatbot not initialized")
            
            # Ensure session exists in memory
            if session_id not in self.sessions:
                # Create session if it doesn't exist
                self.sessions[session_id] = {
                    "created_at": datetime.now(),
                    "current_chatbot": "regular",
                    "message_count": 0,
                    "last_activity": datetime.now(),
                    "input_language": input_language,
                    "voice": voice
                }
            
            # Update session with language/voice preferences
            if session_id in self.sessions:
                self.sessions[session_id]["message_count"] += 1
                self.sessions[session_id]["last_activity"] = datetime.now()
                self.sessions[session_id]["input_language"] = input_language
                self.sessions[session_id]["voice"] = voice
            
            # Get response with timeout (LLM processes in English)
            try:
                response = await asyncio.wait_for(
                    asyncio.to_thread(chatbot.get_response, english_message),
                    timeout=30.0  # 30 second timeout
                )
            except asyncio.TimeoutError:
                response = "I'm sorry, I'm taking too long to respond. Please try again."
            
            # Ensure response is not empty
            if not response or response.strip() == "":
                response = "I'm sorry, I didn't get a proper response. Could you please try again?"
            
            # Step 2: Translate LLM response back to user's language
            final_translation_result = await translation_service.translate_from_english(response, input_language)
            final_response = final_translation_result["translated_text"]
            
            if final_translation_result["translation_needed"]:
                logger.info(f"🌐 Translated LLM response to {input_language}: '{final_response[:50]}...'")
            else:
                logger.info(f"🌐 LLM response already in target language: '{final_response[:50]}...'")
            
            # Log the conversation to MongoDB with language/voice context
            if self.chat_logging:
                try:
                    # Get pending messages before creating MongoDB session
                    pending_messages = self.sessions[session_id].get("pending_messages", [])
                    
                    self.chat_logging.add_message_pair(
                        session_id, 
                        message,  # Log original user message
                        final_response,  # Log final translated response
                        "general_chatbot",
                        input_language=input_language,
                        voice=voice,
                        pending_messages=pending_messages
                    )
                    # Mark MongoDB session as created and clear pending messages
                    if session_id in self.sessions:
                        self.sessions[session_id]["mongodb_session_created"] = True
                        self.sessions[session_id]["pending_messages"] = []  # Clear pending messages
                        logger.info(f"📝 Cleared {len(pending_messages)} pending messages after MongoDB session creation")
                except Exception as e:
                    logger.warning(f"Failed to log conversation: {str(e)}")
            
            # Check for redirect
            redirect = "[ Processing Redirect ]" in final_response
            
            return {
                "response": final_response,
                "redirect": redirect,
                "session_id": session_id,
                "input_language": input_language,
                "voice": voice,
                "translation_info": {
                    "user_translation": translation_result,
                    "response_translation": final_translation_result
                }
            }
            
        except Exception as e:
            logger.error(f"Error in get_regular_response: {str(e)}")
            return {
                "response": f"Sorry, I encountered an error: {str(e)}",
                "redirect": False,
                "session_id": session_id,
                "input_language": input_language,
                "voice": voice
            }
    
    async def get_modify_response(self, message: str, session_id: str, input_language: str = "en-US", voice: str = "alloy") -> Dict[str, Any]:
        """Get response from modify chatbot with language and voice context."""
        try:
            logger.info(f"🔄 Processing modify chatbot request for session {session_id}")
            logger.info(f"🌐 Language: {input_language}, 🎤 Voice: {voice}")
            
            # Step 1: Translate user message to English if needed
            translation_service = get_translation_service()
            translation_result = await translation_service.translate_to_english(message, input_language)
            english_message = translation_result["translated_text"]
            
            if translation_result["translation_needed"]:
                logger.info(f"🌐 Translated user message to English: '{english_message[:50]}...'")
            else:
                logger.info(f"🌐 User message already in English: '{english_message[:50]}...'")
            
            # Get session-specific chatbot (always use English for LLM processing)
            chatbot = self._get_modify_chatbot_for_session(session_id, "en-US")
            if not chatbot:
                raise Exception("Modify chatbot not initialized")
            
            # Ensure session exists in memory
            if session_id not in self.sessions:
                # Create session if it doesn't exist
                self.sessions[session_id] = {
                    "created_at": datetime.now(),
                    "current_chatbot": "modify",
                    "message_count": 0,
                    "last_activity": datetime.now(),
                    "input_language": input_language,
                    "voice": voice
                }
            
            # Update session with language/voice preferences
            if session_id in self.sessions:
                self.sessions[session_id]["message_count"] += 1
                self.sessions[session_id]["last_activity"] = datetime.now()
                self.sessions[session_id]["input_language"] = input_language
                self.sessions[session_id]["voice"] = voice
            
            # Get response with timeout (LLM processes in English)
            try:
                response = await asyncio.wait_for(
                    asyncio.to_thread(chatbot.get_response, english_message),
                    timeout=30.0  # 30 second timeout
                )
            except asyncio.TimeoutError:
                response = "I'm sorry, I'm taking too long to respond. Please try again."
            
            # Ensure response is not empty
            if not response or response.strip() == "":
                response = "I'm sorry, I didn't get a proper response. Could you please try again?"
            
            # Step 2: Translate LLM response back to user's language
            final_translation_result = await translation_service.translate_from_english(response, input_language)
            final_response = final_translation_result["translated_text"]
            
            if final_translation_result["translation_needed"]:
                logger.info(f"🌐 Translated LLM response to {input_language}: '{final_response[:50]}...'")
            else:
                logger.info(f"🌐 LLM response already in target language: '{final_response[:50]}...'")
            
            # Log the conversation to MongoDB with language/voice context
            if self.chat_logging:
                try:
                    # Get pending messages before creating MongoDB session
                    pending_messages = self.sessions[session_id].get("pending_messages", [])
                    
                    self.chat_logging.add_message_pair(
                        session_id, 
                        message,  # Log original user message
                        final_response,  # Log final translated response
                        "modify_chatbot",
                        input_language=input_language,
                        voice=voice,
                        pending_messages=pending_messages
                    )
                    # Mark MongoDB session as created and clear pending messages
                    if session_id in self.sessions:
                        self.sessions[session_id]["mongodb_session_created"] = True
                        self.sessions[session_id]["pending_messages"] = []  # Clear pending messages
                        logger.info(f"📝 Cleared {len(pending_messages)} pending messages after MongoDB session creation")
                except Exception as e:
                    logger.warning(f"Failed to log conversation: {str(e)}")
            
            # Check for redirect
            redirect = "[ Processing Redirect ]" in final_response
            
            return {
                "response": final_response,
                "redirect": redirect,
                "session_id": session_id,
                "input_language": input_language,
                "voice": voice,
                "translation_info": {
                    "user_translation": translation_result,
                    "response_translation": final_translation_result
                }
            }
            
        except Exception as e:
            logger.error(f"Error in get_modify_response: {str(e)}")
            return {
                "response": f"Sorry, I encountered an error: {str(e)}",
                "redirect": False,
                "session_id": session_id,
                "input_language": input_language,
                "voice": voice
            }
    
    async def update_chatbot_type(self, session_id: str, new_chatbot_type: str) -> bool:
        """Update chatbot type for a session (for redirections)."""
        if session_id in self.sessions:
            self.sessions[session_id]["current_chatbot"] = new_chatbot_type
            self.sessions[session_id]["last_activity"] = datetime.now()
        
        # Update in MongoDB
        if self.chat_logging:
            try:
                chat_type = "general_chatbot" if new_chatbot_type == "regular" else "modify_chatbot"
                return self.chat_logging.update_chatbot_type(session_id, chat_type)
            except Exception as e:
                print(f"⚠️ Warning: Failed to update chatbot type: {str(e)}")
                return False
        
        return True
    
    async def end_session(self, session_id: str) -> bool:
        """End a chat session."""
        mongodb_session_created = False
        
        if session_id in self.sessions:
            # Check if MongoDB session was created
            mongodb_session_created = self.sessions[session_id].get("mongodb_session_created", False)
            
            # Cleanup session-specific chatbots
            session_data = self.sessions[session_id]
            if "regular_chatbot" in session_data and hasattr(session_data["regular_chatbot"], 'close_mongodb_connection'):
                session_data["regular_chatbot"].close_mongodb_connection()
            if "modify_chatbot" in session_data and hasattr(session_data["modify_chatbot"], 'close_mongodb_connection'):
                session_data["modify_chatbot"].close_mongodb_connection()
            
            del self.sessions[session_id]
        
        # Only mark as ended in MongoDB if session was actually created
        if self.chat_logging and mongodb_session_created:
            try:
                return self.chat_logging.end_chat_session(session_id)
            except Exception as e:
                print(f"⚠️ Warning: Failed to end chat session: {str(e)}")
                return False
        
        return True
    
    async def cleanup(self):
        """Cleanup resources."""
        try:
            # Cleanup session-specific chatbots
            for session_id, session_data in self.sessions.items():
                if "regular_chatbot" in session_data and hasattr(session_data["regular_chatbot"], 'close_mongodb_connection'):
                    session_data["regular_chatbot"].close_mongodb_connection()
                if "modify_chatbot" in session_data and hasattr(session_data["modify_chatbot"], 'close_mongodb_connection'):
                    session_data["modify_chatbot"].close_mongodb_connection()
            
            # Cleanup global chatbots
            if self.regular_chatbot and hasattr(self.regular_chatbot, 'close_mongodb_connection'):
                self.regular_chatbot.close_mongodb_connection()
            
            if self.modify_chatbot and hasattr(self.modify_chatbot, 'close_mongodb_connection'):
                self.modify_chatbot.close_mongodb_connection()
            
            if self.chat_logging:
                self.chat_logging.close_connection()
                
        except Exception as e:
            print(f"⚠️ Warning during cleanup: {str(e)}")
    
    def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session information."""
        return self.sessions.get(session_id)
    
    def get_all_sessions(self) -> Dict[str, Dict[str, Any]]:
        """Get all active sessions."""
        return self.sessions.copy()
