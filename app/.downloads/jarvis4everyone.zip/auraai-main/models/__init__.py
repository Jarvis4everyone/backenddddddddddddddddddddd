"""
Pydantic models for the AURA API.
"""

from pydantic import BaseModel, validator
from typing import Optional, Dict, Any, Literal, List
from datetime import datetime

# Supported languages
SUPPORTED_LANGUAGES = ["en-US", "en-GB", "hi-IN", "pa-IN", "ru-RU"]

# Supported voices
SUPPORTED_VOICES = ["ash", "onyx", "echo", "fable", "alloy", "nova", "shimmer", "coral", "sage"]

class ChatRequest(BaseModel):
    """Request model for chat endpoints."""
    message: str
    session_id: Optional[str] = None

class ChatResponse(BaseModel):
    """Response model for chat endpoints."""
    response: str
    session_id: str
    chatbot_type: str
    redirect: bool = False
    timestamp: datetime = datetime.now()

class WebSocketMessage(BaseModel):
    """WebSocket message model."""
    type: str  # "chat", "ping", "pong", "welcome", "response", "redirect"
    message: Optional[str] = None
    chatbot_type: Optional[str] = None
    session_id: Optional[str] = None
    redirect: Optional[bool] = None
    input_language: Optional[str] = "en-US"  # NEW FIELD - Language preference
    voice: Optional[str] = "alloy"  # NEW FIELD - Voice preference
    
    @validator('input_language')
    def validate_language(cls, v):
        if v not in SUPPORTED_LANGUAGES:
            return "en-US"  # Default to English if invalid
        return v
    
    @validator('voice')
    def validate_voice(cls, v):
        if v not in SUPPORTED_VOICES:
            return "alloy"  # Default to alloy if invalid
        return v

class ServiceTypeItem(BaseModel):
    """Model for individual service type items."""
    name: str
    service_status: str = "pending"

class ServiceRequest(BaseModel):
    """Model for service requests saved to MongoDB."""
    customer_name: str
    contact_number: str
    truck_id: str
    truck_company_name: str
    service_type: List[ServiceTypeItem]
    priority: str
    notes: str
    status: str = "requested"
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()
    created_by: str = "auraai"
    source: str = "aiassistantaura"
    auto_approved: bool = False

class UpdateRequest(BaseModel):
    """Model for updating service requests."""
    field: str
    new_value: Any
    customer_name: str
    contact_number: str
