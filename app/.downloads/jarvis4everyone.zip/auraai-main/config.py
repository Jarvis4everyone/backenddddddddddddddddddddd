"""
Configuration settings for the AURA Backend API.
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Settings:
    """Application settings."""
    
    # API Settings
    API_TITLE = "AURA Backend API"
    API_VERSION = "1.0.0"
    API_DESCRIPTION = "Backend API for AURA truck service chatbot system"
    
    # Server Settings
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", 4000))
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    
    # OpenAI Settings
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4")
    
    # MongoDB Settings
    MONGODB_URL = os.getenv("MongoDB_URL")
    MONGODB_DATABASE = os.getenv("MONGODB_DATABASE", "aura")
    MONGODB_COLLECTION = os.getenv("MONGODB_COLLECTION", "customer_requests")
    
    # CORS Settings
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
    
    # Session Settings
    SESSION_TIMEOUT_MINUTES = int(os.getenv("SESSION_TIMEOUT_MINUTES", 30))
    MAX_SESSIONS = int(os.getenv("MAX_SESSIONS", 1000))
    
    # Learning Data Settings
    LEARNING_DATA_COLLECTION = os.getenv("LEARNING_DATA_COLLECTION", "Learning_data")
    LEARNING_DATA_PATH = os.getenv("LEARNING_DATA_PATH", "Data/learning_data")
    
    @classmethod
    def validate(cls):
        """Validate required settings."""
        required_settings = [
            ("OPENAI_API_KEY", cls.OPENAI_API_KEY),
            ("MONGODB_URL", cls.MONGODB_URL),
        ]
        
        missing = []
        for name, value in required_settings:
            if not value:
                missing.append(name)
        
        if missing:
            raise ValueError(f"Missing required environment variables: {', '.join(missing)}")

# Create global settings instance
settings = Settings()
