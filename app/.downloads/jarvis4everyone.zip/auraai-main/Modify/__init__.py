"""
AURA Modify Assistant Package
A chatbot for updating existing service requests in MongoDB.
"""

from .Chatbot import ModifyChatbot
from .Prompt import get_system_prompt

__version__ = "1.0.0"
__author__ = "AURA Team"
__description__ = "AURA Modify Assistant - Update existing service requests"

__all__ = [
    "ModifyChatbot",
    "get_system_prompt"
]
