import os
import re
import sys
from typing import Optional, Dict, Any, List
from openai import OpenAI
from datetime import datetime
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from dotenv import load_dotenv
from .Prompt import get_system_prompt

# Add parent directory to path for LearningManager
sys.path.append('..')
# Import LearningManager only when needed to avoid circular imports

# Load environment variables
load_dotenv()

class ModifyChatbot:
    """
    AURA Modify Assistant - Simple chatbot for updating service requests.
    """
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4", shared_learning_manager=None, input_language: str = "en-US"):
        """
        Initialize the Modify Chatbot.
        
        Args:
            api_key (Optional[str]): OpenAI API key
            model (str): OpenAI model to use
            shared_learning_manager: Shared LearningManager instance to avoid duplicate initialization
            input_language (str): User's input language code for responses
        """
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable or pass api_key parameter.")
        
        self.client = OpenAI(api_key=self.api_key)
        self.model = model
        self.input_language = input_language
        self.system_prompt = get_system_prompt(input_language)
        
        # MongoDB connection
        self.mongodb_url = os.getenv("MongoDB_URL")
        if not self.mongodb_url:
            raise ValueError("MongoDB_URL not found in environment variables")
        
        self.mongodb_client = None
        self.db = None
        self.collection = None
        self._connect_to_mongodb()
        
        # Initialize Learning Manager
        if shared_learning_manager:
            self.learning_manager = shared_learning_manager
        else:
            try:
                from Data.LearningManager import LearningManager
                self.learning_manager = LearningManager()
            except Exception as e:
                print(f"⚠️ Warning: Learning Manager initialization failed: {str(e)}")
                self.learning_manager = None
        
        # Chat history
        self.chat_history: List[Dict[str, str]] = [
            {"role": "system", "content": self.system_prompt}
        ]
    
    def update_language(self, input_language: str):
        """Update the chatbot's language and regenerate system prompt."""
        self.input_language = input_language
        self.system_prompt = get_system_prompt(input_language)
        
        # Update the first message in chat history (system prompt)
        if self.chat_history and self.chat_history[0]["role"] == "system":
            self.chat_history[0]["content"] = self.system_prompt
        
    
    def _connect_to_mongodb(self):
        """Connect to MongoDB database."""
        try:
            self.mongodb_client = MongoClient(self.mongodb_url, serverSelectionTimeoutMS=5000)
            self.db = self.mongodb_client.aura
            self.collection = self.db.customer_requests
            # Test connection
            self.mongodb_client.admin.command('ping')
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            print(f"❌ Failed to connect to MongoDB: {str(e)}")
            raise
    
    def get_response(self, user_message: str) -> str:
        """
        Get response from the chatbot.
        
        Args:
            user_message (str): User's message
            
        Returns:
            str: Chatbot's response
        """
        try:
            # Add user message to history
            self.add_message("user", user_message)
            
            # Get relevant context from Learning Manager if available
            context = ""
            if self.learning_manager:
                context = self.learning_manager.get_context_for_query(user_message)
            
            # Prepare messages with context
            messages = self.chat_history.copy()
            if context:
                # Add context as a strong system instruction
                context_message = f"""IMPORTANT: You must answer based on the following knowledge base information. Use this data to provide accurate, specific answers. Do not make up information that's not in this knowledge base.

KNOWLEDGE BASE DATA:
{context}

INSTRUCTIONS: Always reference the specific information from the knowledge base above when answering questions. If the user asks about services, pricing, contact information, or any other details, use ONLY the information provided in the knowledge base."""
                messages.append({"role": "system", "content": context_message})
            
            # Get response from OpenAI
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=1000,
                temperature=0.7,
                top_p=1.0,
                frequency_penalty=0.0,
                presence_penalty=0.0
            )
            
            assistant_response = response.choices[0].message.content.strip()
            
            # Check if the assistant is asking to check database
            if "[ Checking Database" in assistant_response:
                assistant_response = self._handle_database_check(assistant_response)
            
            # Check if the assistant is returning a confirmed dictionary
            if '"Status": "Requested"' in assistant_response and '"FullName":' in assistant_response:
                print(f"🔍 Detected dictionary response in modify chatbot: {assistant_response[:100]}...")
                assistant_response = self._handle_request_update(assistant_response)
            
            # Add assistant response to history
            self.add_message("assistant", assistant_response)
            
            return assistant_response
            
        except Exception as e:
            error_msg = f"Error getting response: {str(e)}"
            self.add_message("assistant", error_msg)
            return error_msg
    
    def _handle_database_check(self, assistant_response: str) -> str:
        """Handle database checking when assistant asks to check database."""
        try:
            # Extract name and contact from the response
            # Pattern: [ Checking Database - Name,ContactNumber ]
            pattern = r'\[ Checking Database - ([^,]+),([^\]]+) \]'
            match = re.search(pattern, assistant_response)
            
            if not match:
                return assistant_response + "\n\n❌ Could not extract name and contact from the message."
            
            name = match.group(1).strip()
            contact = match.group(2).strip()
            
            print(f"🔍 Searching for: Name='{name}', Contact='{contact}'")
            
            # Clean and normalize the contact number (remove spaces, dashes, etc.)
            contact_clean = re.sub(r'[^\d]', '', contact)
            
            # Enhanced name matching strategies
            name_variations = self._generate_name_variations(name)
            
            # Search MongoDB for the request with multiple strategies
            search_queries = []
            
            # Generate queries for each name variation
            for name_var in name_variations:
                search_queries.extend([
                    # Exact match with cleaned contact
                    {
                        "customer_name": {"$regex": name_var, "$options": "i"},
                        "contact_number": contact_clean
                    },
                    # Original contact number
                    {
                        "customer_name": {"$regex": name_var, "$options": "i"},
                        "contact_number": contact
                    },
                    # Partial name match with cleaned contact
                    {
                        "customer_name": {"$regex": f".*{name_var}.*", "$options": "i"},
                        "contact_number": contact_clean
                    },
                    # Fuzzy matching with contact
                    {
                        "customer_name": {"$regex": f".*{name_var}.*", "$options": "i"},
                        "contact_number": contact
                    }
                ])
            
            # Add phonetic matching queries
            phonetic_queries = self._generate_phonetic_queries(name, contact_clean, contact)
            search_queries.extend(phonetic_queries)
            
            requests_list = []
            for query in search_queries:
                requests = self.collection.find(query)
                requests_list = list(requests)
                if requests_list:
                    print(f"✅ Found {len(requests_list)} requests with query: {query}")
                    break
            
            if not requests_list:
                # Let's also try a broader search to see what's in the database
                all_requests = list(self.collection.find({}).limit(5))
                print(f"🔍 Database sample (first 5 records): {[{'name': r.get('customer_name'), 'contact': r.get('contact_number')} for r in all_requests]}")
                
                # Try to find similar names or contacts
                similar_requests = []
                
                # Search for similar names using enhanced matching
                name_variations = self._generate_name_variations(name)
                for name_var in name_variations:
                    similar = list(self.collection.find({
                        "customer_name": {"$regex": name_var, "$options": "i"}
                    }).limit(5))
                    similar_requests.extend(similar)
                
                # Search for similar contact numbers (partial match)
                if len(contact_clean) >= 6:  # Only if contact is long enough
                    similar_contacts = list(self.collection.find({
                        "contact_number": {"$regex": contact_clean[-6:], "$options": "i"}
                    }).limit(5))
                    similar_requests.extend(similar_contacts)
                
                # Calculate similarity scores and sort by relevance
                scored_requests = []
                for req in similar_requests:
                    db_name = req.get('customer_name', '')
                    db_contact = req.get('contact_number', '')
                    
                    # Calculate name similarity
                    name_similarity = self._calculate_name_similarity(name, db_name)
                    
                    # Calculate contact similarity
                    contact_similarity = 0.0
                    if contact_clean and db_contact:
                        if contact_clean == db_contact:
                            contact_similarity = 1.0
                        elif contact_clean in db_contact or db_contact in contact_clean:
                            contact_similarity = 0.8
                        elif len(contact_clean) >= 6 and contact_clean[-6:] in db_contact:
                            contact_similarity = 0.6
                    
                    # Combined score (weight name more heavily)
                    combined_score = (name_similarity * 0.7) + (contact_similarity * 0.3)
                    
                    if combined_score > 0.3:  # Only include reasonably similar matches
                        scored_requests.append((req, combined_score))
                
                # Sort by similarity score and remove duplicates
                scored_requests.sort(key=lambda x: x[1], reverse=True)
                unique_similar = []
                seen_ids = set()
                for req, score in scored_requests:
                    if req.get('_id') not in seen_ids:
                        unique_similar.append((req, score))
                        seen_ids.add(req.get('_id'))
                
                error_msg = f"\n\n❌ No service request found for:\n- Name: {name}\n- Contact: {contact}\n\nPlease check your information or contact our support team if you believe this is an error."
                
                if unique_similar:
                    error_msg += f"\n\n💡 Did you mean one of these?\n"
                    for i, (req, score) in enumerate(unique_similar[:3], 1):
                        similarity_percent = int(score * 100)
                        error_msg += f"{i}. {req.get('customer_name', 'N/A')} - {req.get('contact_number', 'N/A')} ({similarity_percent}% match)\n"
                
                return assistant_response + error_msg
            
            elif len(requests_list) == 1:
                request = requests_list[0]
                # Convert ObjectIds to strings for safe handling
                request = self._convert_object_ids_to_strings(request)
                
                # Format the request data in a clean, readable format
                service_types = request.get('service_type', [])
                if isinstance(service_types, list):
                    # Handle new format with objects containing name and service_status
                    if service_types and isinstance(service_types[0], dict):
                        service_type_str = ", ".join([service.get('name', '') for service in service_types])
                    else:
                        # Handle old format with simple strings
                        service_type_str = ", ".join(service_types)
                else:
                    service_type_str = str(service_types)
                
                request_data = f"""Great, I found your already existing service request in the database.

Here are the details of your request from the database:

Full Name : {request.get('customer_name', 'N/A')}
Contact Number : {request.get('contact_number', 'N/A')}
Truck ID : {request.get('truck_id', 'N/A')}
Truck Company Name : {request.get('truck_company_name', 'N/A')}
Service Type : {service_type_str}
Priority : {request.get('priority', 'N/A')}
Notes : {request.get('notes', 'N/A')}"""
                
                return assistant_response + "\n\n" + request_data
            
            else:
                # Multiple requests found
                summary = f"\n\nI found {len(requests_list)} service requests for you:\n\n"
                for i, req in enumerate(requests_list, 1):
                    summary += f"{i}. Truck ID: {req.get('truck_id', 'N/A')} - {req.get('service_type', 'N/A')} - {req.get('priority', 'N/A')}\n"
                
                summary += "\nPlease specify which request you'd like to modify by mentioning the Truck ID."
                return assistant_response + summary
                
        except Exception as e:
            print(f"❌ Error in database check: {str(e)}")
            return assistant_response + f"\n\n❌ Error searching database: {str(e)}"
    
    def _handle_request_update(self, assistant_response: str) -> str:
        """Handle updating the request in MongoDB when confirmed dictionary is received."""
        try:
            print(f"🔄 Processing request update...")
            
            # Extract the JSON dictionary from the response
            json_start = assistant_response.find('{')
            json_end = assistant_response.rfind('}')
            
            if json_start == -1 or json_end == -1 or json_start >= json_end:
                print(f"❌ Could not find JSON dictionary in response")
                return assistant_response
            
            json_str = assistant_response[json_start:json_end + 1]
            print(f"📋 Extracted JSON: {json_str}")
            
            # Parse the JSON
            import json
            data = json.loads(json_str)
            
            # Extract the data
            customer_name = data.get('FullName', '')
            contact_number = data.get('ContactNumber', '')
            
            print(f"🔍 Looking for request: Name={customer_name}, Contact={contact_number}")
            
            # Clean and normalize the contact number
            contact_clean = re.sub(r'[^\d]', '', contact_number)
            
            # Enhanced name matching for update requests
            name_variations = self._generate_name_variations(customer_name)
            
            # Find the existing request in MongoDB with multiple search strategies
            search_queries = []
            
            # Generate queries for each name variation
            for name_var in name_variations:
                search_queries.extend([
                    {
                        "customer_name": {"$regex": name_var, "$options": "i"},
                        "contact_number": contact_clean
                    },
                    {
                        "customer_name": {"$regex": name_var, "$options": "i"},
                        "contact_number": contact_number
                    }
                ])
            
            # Add phonetic matching queries
            phonetic_queries = self._generate_phonetic_queries(customer_name, contact_clean, contact_number)
            search_queries.extend(phonetic_queries)
            
            existing_request = None
            for query in search_queries:
                existing_request = self.collection.find_one(query)
                if existing_request:
                    print(f"✅ Found existing request with query: {query}")
                    break
            
            if not existing_request:
                print(f"❌ Could not find existing request in database")
                return assistant_response + "\n\n❌ Could not find the original request to update."
            
            print(f"✅ Found existing request: {existing_request.get('_id')}")
            
            # Prepare the update data
            service_types = data.get('ServiceType', [])
            # Convert service_type from list of strings to list of objects if needed
            if isinstance(service_types, list) and service_types:
                if isinstance(service_types[0], str):
                    # Convert strings to objects
                    service_type_objects = []
                    for service in service_types:
                        service_type_objects.append({
                            "name": service,
                            "service_status": "pending"
                        })
                    service_types = service_type_objects
                # If already objects, keep as is
            
            update_data = {
                "status": "requested",  # Keep status as "requested" when updating
                "customer_name": data.get('FullName', ''),
                "contact_number": data.get('ContactNumber', ''),
                "truck_id": data.get('TruckId', ''),
                "truck_company_name": data.get('TruckCompanyName', ''),
                "service_type": service_types,
                "priority": data.get('Priority', '').lower(),
                "notes": data.get('Notes', ''),
                "updated_at": datetime.utcnow()
            }
            
            print(f"📝 Update data: {update_data}")
            
            # Update the request in MongoDB
            update_result = self.collection.update_one(
                {"_id": existing_request["_id"]},
                {"$set": update_data}
            )
            
            if update_result.modified_count > 0:
                print(f"✅ Successfully updated request in MongoDB")
                return assistant_response + "\n\n✅ Your request has been successfully updated in our database!"
            else:
                print(f"❌ Failed to update request in MongoDB")
                return assistant_response + "\n\n❌ Failed to update the request in the database."
                
        except Exception as e:
            print(f"❌ Error updating request: {str(e)}")
            return assistant_response + f"\n\n❌ Error updating request: {str(e)}"
    
    def add_message(self, role: str, content: str) -> None:
        """Add a message to the chat history."""
        self.chat_history.append({"role": role, "content": content})
    
    def clear_history(self) -> None:
        """Clear chat history."""
        self.chat_history = [
            {"role": "system", "content": self.system_prompt}
        ]
    
    def _generate_name_variations(self, name: str) -> List[str]:
        """Generate various name variations for flexible matching."""
        variations = [name.strip()]
        
        # Split name into parts
        name_parts = name.strip().split()
        
        # Add individual parts
        for part in name_parts:
            if len(part) > 1:  # Only add parts longer than 1 character
                variations.append(part)
        
        # Add combinations of parts
        if len(name_parts) >= 2:
            # First name + Last name
            variations.append(f"{name_parts[0]} {name_parts[-1]}")
            # All parts except middle names
            if len(name_parts) > 2:
                variations.append(f"{name_parts[0]} {name_parts[-1]}")
        
        # Add variations with common name modifications
        for variation in variations.copy():
            # Remove common suffixes
            suffixes_to_remove = ['jr', 'sr', 'ii', 'iii', 'iv']
            for suffix in suffixes_to_remove:
                if variation.lower().endswith(f' {suffix}'):
                    variations.append(variation[:-len(f' {suffix}')].strip())
            
            # Handle common name variations
            if ' ' in variation:
                # Swap first and last name
                parts = variation.split()
                if len(parts) == 2:
                    variations.append(f"{parts[1]} {parts[0]}")
        
        # Remove duplicates and empty strings
        unique_variations = []
        seen = set()
        for var in variations:
            var_clean = var.strip()
            if var_clean and var_clean.lower() not in seen:
                unique_variations.append(var_clean)
                seen.add(var_clean.lower())
        
        return unique_variations
    
    def _generate_phonetic_queries(self, name: str, contact_clean: str, contact: str) -> List[Dict]:
        """Generate phonetic matching queries for similar sounding names."""
        phonetic_queries = []
        
        # Common phonetic substitutions
        phonetic_map = {
            'c': ['k', 's'],
            'k': ['c', 'q'],
            's': ['c', 'z'],
            'z': ['s'],
            'ph': ['f'],
            'f': ['ph'],
            'th': ['t'],
            't': ['th'],
            'v': ['b'],
            'b': ['v'],
            'j': ['g'],
            'g': ['j'],
            'w': ['v'],
            'y': ['i'],
            'i': ['y', 'e'],
            'e': ['i', 'a'],
            'a': ['e', 'o'],
            'o': ['a', 'u'],
            'u': ['o']
        }
        
        # Generate phonetic variations
        name_lower = name.lower()
        phonetic_variations = [name_lower]
        
        for original, replacements in phonetic_map.items():
            for replacement in replacements:
                if original in name_lower:
                    phonetic_var = name_lower.replace(original, replacement)
                    phonetic_variations.append(phonetic_var)
        
        # Create queries for phonetic variations
        for phonetic_var in phonetic_variations:
            phonetic_queries.extend([
                {
                    "customer_name": {"$regex": phonetic_var, "$options": "i"},
                    "contact_number": contact_clean
                },
                {
                    "customer_name": {"$regex": phonetic_var, "$options": "i"},
                    "contact_number": contact
                }
            ])
        
        return phonetic_queries
    
    def _calculate_name_similarity(self, name1: str, name2: str) -> float:
        """Calculate similarity between two names using multiple algorithms."""
        name1_clean = name1.lower().strip()
        name2_clean = name2.lower().strip()
        
        # Exact match
        if name1_clean == name2_clean:
            return 1.0
        
        # Check if one name contains the other
        if name1_clean in name2_clean or name2_clean in name1_clean:
            return 0.8
        
        # Split into parts and check for partial matches
        parts1 = set(name1_clean.split())
        parts2 = set(name2_clean.split())
        
        if parts1 and parts2:
            # Calculate Jaccard similarity
            intersection = parts1.intersection(parts2)
            union = parts1.union(parts2)
            jaccard_similarity = len(intersection) / len(union) if union else 0
            
            if jaccard_similarity > 0.5:
                return jaccard_similarity
        
        # Check for common prefixes/suffixes
        if len(name1_clean) > 3 and len(name2_clean) > 3:
            # Check first 3 characters
            if name1_clean[:3] == name2_clean[:3]:
                return 0.6
            # Check last 3 characters
            if name1_clean[-3:] == name2_clean[-3:]:
                return 0.6
        
        return 0.0
    
    def test_name_matching(self, test_name: str) -> str:
        """Test method to demonstrate name matching capabilities."""
        try:
            variations = self._generate_name_variations(test_name)
            phonetic_queries = self._generate_phonetic_queries(test_name, "1234567890", "1234567890")
            
            result = f"🔍 Name Matching Test for: '{test_name}'\n\n"
            result += f"📝 Generated Variations ({len(variations)}):\n"
            for i, var in enumerate(variations, 1):
                result += f"{i}. {var}\n"
            
            result += f"\n🔊 Phonetic Queries ({len(phonetic_queries)}):\n"
            for i, query in enumerate(phonetic_queries[:5], 1):  # Show first 5
                result += f"{i}. {query}\n"
            
            # Test similarity with some sample names
            sample_names = ["John Smith", "Jon Smith", "Johnny Smith", "Smith John", "J Smith"]
            result += f"\n📊 Similarity Scores:\n"
            for sample in sample_names:
                similarity = self._calculate_name_similarity(test_name, sample)
                result += f"'{test_name}' vs '{sample}': {similarity:.2f}\n"
            
            return result
            
        except Exception as e:
            return f"❌ Test error: {str(e)}"
    
    def debug_database_contents(self) -> str:
        """Debug method to show database contents for troubleshooting."""
        try:
            # Get all requests
            all_requests = list(self.collection.find({}).limit(10))
            
            debug_info = "🔍 Database Debug Info:\n"
            debug_info += f"Total requests found: {len(all_requests)}\n\n"
            
            for i, req in enumerate(all_requests, 1):
                debug_info += f"{i}. Name: '{req.get('customer_name', 'N/A')}' | Contact: '{req.get('contact_number', 'N/A')}' | Truck: '{req.get('truck_id', 'N/A')}'\n"
            
            return debug_info
            
        except Exception as e:
            return f"❌ Debug error: {str(e)}"
    
    def _convert_object_ids_to_strings(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recursively convert all ObjectId fields to strings in a MongoDB document.
        This makes the document JSON-serializable and future-proof.
        
        Args:
            document: MongoDB document (dict)
            
        Returns:
            Dict[str, Any]: Document with ObjectIds converted to strings
        """
        if not isinstance(document, dict):
            return document
        
        converted_doc = {}
        
        for key, value in document.items():
            if isinstance(value, dict):
                # Handle nested objects (like {"$oid": "..."})
                if "$oid" in value:
                    converted_doc[key] = str(value["$oid"])
                elif "$date" in value:
                    # Handle date objects
                    converted_doc[key] = value["$date"]
                else:
                    # Recursively convert nested dictionaries
                    converted_doc[key] = self._convert_object_ids_to_strings(value)
            elif hasattr(value, '__class__') and value.__class__.__name__ == 'ObjectId':
                # Handle direct ObjectId objects
                converted_doc[key] = str(value)
            elif isinstance(value, list):
                # Handle lists that might contain ObjectIds
                converted_doc[key] = [
                    self._convert_object_ids_to_strings(item) if isinstance(item, dict) 
                    else str(item) if hasattr(item, '__class__') and item.__class__.__name__ == 'ObjectId'
                    else item
                    for item in value
                ]
            elif hasattr(value, 'isoformat'):
                # Handle datetime objects
                converted_doc[key] = value.isoformat()
            else:
                # Keep other values as-is
                converted_doc[key] = value
        
        return converted_doc
    
    def close_mongodb_connection(self):
        """Close MongoDB connection."""
        if self.mongodb_client:
            self.mongodb_client.close()