"""
Startup script for the AURA Backend API.
"""

import uvicorn
from config import settings

if __name__ == "__main__":
    try:
        settings.validate()
    except ValueError as e:
        print(f"❌ Configuration error: {e}")
        exit(1)
    
    uvicorn.run(
        "app:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info" if not settings.DEBUG else "debug"
    )
