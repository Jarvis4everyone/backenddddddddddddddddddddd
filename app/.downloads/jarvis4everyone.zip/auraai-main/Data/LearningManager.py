"""
Learning Manager for FAISS-based Vector Search
This module handles vector database operations using LangChain and FAISS.
"""

import os
import PyPDF2
from typing import List, Dict, Any, Optional
import logging
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
import shutil
import re
from pathlib import Path
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class LearningManager:
    def __init__(self, learning_dir: str = "Data/learning_data"):
        self.learning_dir = learning_dir
        self.vector_store = None
        self.mongodb_client = None
        self.db = None
        self.learning_collection = None
        
        # Initialize embeddings with explicit parameters
        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-3-small",
            openai_api_key=os.getenv("OPENAI_API_KEY")
        )
        
        os.makedirs(learning_dir, exist_ok=True)
        
        # Connect to MongoDB and download learning data
        self._connect_to_mongodb()
        self._download_learning_data()
        
        # Reset and rebuild index on every startup
        self.rebuild_index()
        # Make sure we initialize the vector store to use it
        self.initialize_vector_store()
        # Cache file content to original names
        self._file_mapping = self._build_file_mapping()
        
        print("✅ LearningManager initialized successfully!")

    def _connect_to_mongodb(self):
        """Connect to MongoDB database."""
        try:
            mongodb_url = os.getenv("MongoDB_URL")
            if not mongodb_url:
                raise ValueError("MongoDB_URL not found in environment variables")
                
            self.mongodb_client = MongoClient(
                mongodb_url, 
                serverSelectionTimeoutMS=5000,
                retryWrites=True,
                w='majority'
            )
            self.db = self.mongodb_client.aura
            self.learning_collection = self.db.Learning_data
            # Test connection
            self.mongodb_client.admin.command('ping')
            print("✅ Connected to MongoDB for learning data")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            print(f"❌ Failed to connect to MongoDB: {str(e)}")
            raise

    def _download_learning_data(self):
        """Download learning data from MongoDB and save as text files."""
        try:
            print("🔄 Downloading learning data from MongoDB...")
            
            # Get all documents from Learning_data collection
            documents = list(self.learning_collection.find({}))
            
            if not documents:
                print("⚠️ No learning data found in MongoDB Learning_data collection")
                return
            
            # Save each document as a text file
            for i, doc in enumerate(documents):
                filename = doc.get("filename", f"{i+1}.txt")
                content = doc.get("content", "")
                
                if content:
                    file_path = os.path.join(self.learning_dir, filename)
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"✅ Saved: {filename}")
            
            print(f"✅ Downloaded {len(documents)} learning documents to {self.learning_dir}")
                
        except Exception as e:
            print(f"❌ Error downloading learning data: {str(e)}")
            raise

    def _build_file_mapping(self) -> Dict[str, str]:
        """Build a mapping from numbered filenames to original document names"""
        mapping = {}
        
        # Get all text files in the learning directory
        files = [f for f in os.listdir(self.learning_dir) 
                if os.path.isfile(os.path.join(self.learning_dir, f)) 
                and f.endswith('.txt')]
        
        for filename in files:
            file_path = os.path.join(self.learning_dir, filename)
            
            # Read the first line of the file to get the title
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    first_line = f.readline().strip()
                    
                    # Extract title from markdown header
                    if first_line.startswith('# '):
                        title = first_line[2:].strip()
                    else:
                        # Use the filename without extension as fallback
                        title = Path(filename).stem
                    
                    mapping[file_path] = title
            except Exception as e:
                logger.error(f"Error reading title from {file_path}: {e}")
                mapping[file_path] = Path(filename).stem
                
        logger.info(f"Built mapping for {len(mapping)} files with original titles")
        return mapping

    def get_original_doc_name(self, file_path: str) -> str:
        """Get the original document name from file path"""
        if file_path in self._file_mapping:
            return self._file_mapping[file_path]
        return os.path.basename(file_path)

    def rebuild_index(self):
        """Delete existing index and rebuild from all files in learning directory"""
        # Delete existing FAISS index if it exists
        faiss_index_path = os.path.join(self.learning_dir, "faiss_index")
        if os.path.exists(faiss_index_path):
            logger.info(f"Removing existing FAISS index at {faiss_index_path}")
            shutil.rmtree(faiss_index_path)
            
        # Reset vector store
        self.vector_store = None
        
        # Process all documents in the learning directory
        processed_count = 0
        files = [f for f in os.listdir(self.learning_dir) 
                 if os.path.isfile(os.path.join(self.learning_dir, f)) 
                 and not f.startswith('.')
                 and f.endswith(('.txt', '.pdf'))]  # Only process txt and pdf files
        
        logger.info(f"Found {len(files)} files to process")
        
        for filename in files:
            file_path = os.path.join(self.learning_dir, filename)
            # Skip the faiss_index directory itself if it exists
            if os.path.isdir(file_path) or "faiss_index" in file_path or filename == "README.md":
                continue
                
            logger.info(f"Processing file: {filename}")
            if self.process_document(file_path):
                processed_count += 1
                
        logger.info(f"Rebuilt index with {processed_count} documents")

    def initialize_vector_store(self):
        """Initialize or load the vector store"""
        faiss_index_path = os.path.join(self.learning_dir, "faiss_index")
        if os.path.exists(faiss_index_path):
            try:
                self.vector_store = FAISS.load_local(
                    faiss_index_path,
                    self.embeddings,
                    allow_dangerous_deserialization=True
                )
                logger.info("Successfully loaded FAISS index from %s", faiss_index_path)
            except Exception as e:
                logger.error("Error loading FAISS index: %s", e)
                logger.info("Creating a new vector store instead")
                self.vector_store = None
        else:
            logger.info("No existing FAISS index found at %s", faiss_index_path)
            self.vector_store = None

    def is_pdf(self, file_path: str) -> bool:
        """Check if file is a PDF by reading its header"""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(5)
                return header.startswith(b'%PDF-')
        except Exception:
            return False

    def read_file(self, file_path: str) -> str:
        """Read content from various file types"""
        try:
            # First try to read as text
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            except UnicodeDecodeError:
                # If not text, check if it's a PDF
                if self.is_pdf(file_path):
                    text = ""
                    with open(file_path, 'rb') as f:
                        pdf_reader = PyPDF2.PdfReader(f)
                        for page in pdf_reader.pages:
                            text += page.extract_text()
                    return text
                else:
                    logger.warning(f"Unsupported file type: {file_path}")
                    return ""
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {e}")
            return ""

    def process_document(self, file_path: str) -> bool:
        """Process a document and add it to the vector store"""
        try:
            logger.info(f"Starting to process document: {file_path}")
            content = self.read_file(file_path)
            if not content:
                logger.warning(f"No content extracted from {file_path}")
                return False

            # Split text into smaller chunks for better semantic search
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=800,  # Smaller chunk size for more precise matching
                chunk_overlap=250,  # Increased overlap to avoid losing context at boundaries
                length_function=len,
                separators=["\n\n\n", "\n\n", "\n", " ", ""]  # Better separation
            )
            texts = text_splitter.split_text(content)
            
            if not texts:
                logger.warning(f"No text chunks created from {file_path}")
                return False
                
            logger.info(f"Created {len(texts)} text chunks from {file_path}")
            
            # Create documents with enhanced metadata
            documents = []
            for i, text in enumerate(texts):
                # Add more context to metadata
                metadata = {
                    "source": file_path,
                    "chunk_id": i,
                    "total_chunks": len(texts),
                    "filename": os.path.basename(file_path),
                }
                documents.append(Document(page_content=text, metadata=metadata))
            
            # Add to vector store
            if self.vector_store is None:
                logger.info(f"Creating new FAISS index with {len(documents)} documents")
                self.vector_store = FAISS.from_documents(documents, self.embeddings)
                # Save immediately after creation
                faiss_index_path = os.path.join(self.learning_dir, "faiss_index")
                os.makedirs(faiss_index_path, exist_ok=True)
                self.vector_store.save_local(faiss_index_path)
                logger.info(f"Saved new FAISS index to {faiss_index_path}")
            else:
                logger.info(f"Adding {len(documents)} documents to existing FAISS index")
                self.vector_store.add_documents(documents)
                # Save the updated vector store
                self.vector_store.save_local(os.path.join(self.learning_dir, "faiss_index"))
                logger.info(f"Updated FAISS index with new documents")
            
            logger.info(f"Successfully processed and indexed document: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error processing document {file_path}: {e}")
            return False

    def query_knowledge(self, query: str, k: int = 5, similarity_threshold: float = 0.75) -> List[Dict]:
        """
        Query the knowledge base with improved relevance filtering and more results
        
        Args:
            query: The query string
            k: Number of results to return (higher for more comprehensive answers)
            similarity_threshold: Score threshold for relevance filtering (1.0 is identical, lower returns more results)
            
        Returns:
            List of relevant document chunks with metadata
        """
        if self.vector_store is None:
            logger.warning("No vector store available for querying. Initializing...")
            self.initialize_vector_store()
            
            if self.vector_store is None:
                logger.warning("Still no vector store after initialization attempt")
                return []
        
        try:
            # Log the query for debugging
            logger.info(f"Querying knowledge base with: {query}")
            
            # Get more results initially for better filtering
            results = self.vector_store.similarity_search_with_score(query, k=k+3)
            
            # Process and enhance the results
            formatted_results = []
            seen_content = set()  # To avoid duplicate content
            
            for doc, score in results:
                # Normalize score (FAISS distances are opposite - smaller is better)
                # Convert to a similarity score where 1.0 is perfect match
                normalized_score = 1.0 - min(score, 1.0)
                
                # Skip if below threshold
                if normalized_score < similarity_threshold:
                    continue
                
                # Skip duplicates (sometimes chunks are very similar)
                content_hash = hash(doc.page_content.strip())
                if content_hash in seen_content:
                    continue
                seen_content.add(content_hash)
                
                # Get original document name
                source_path = doc.metadata.get("source", "unknown")
                doc_name = self.get_original_doc_name(source_path)
                
                # Format and add the result
                formatted_results.append({
                    "content": doc.page_content,
                    "source": source_path,
                    "doc_name": doc_name,
                    "score": normalized_score,
                    "chunk_id": doc.metadata.get("chunk_id", 0),
                    "total_chunks": doc.metadata.get("total_chunks", 1)
                })
            
            # Sort by relevance score (highest first)
            formatted_results.sort(key=lambda x: x["score"], reverse=True)
            
            # Limit to k results after filtering
            formatted_results = formatted_results[:k]
            
            logger.info(f"Found {len(formatted_results)} relevant results for query")
            return formatted_results
        except Exception as e:
            logger.error(f"Error querying knowledge base: {e}")
            return []
            
    def format_knowledge_context(self, relevant_info: List[Dict]) -> str:
        """
        Format retrieved knowledge into a user-friendly context string with clearer citations
        
        Args:
            relevant_info: List of relevant document chunks from query_knowledge
            
        Returns:
            Formatted context string with source citations
        """
        if not relevant_info:
            return ""
            
        # Group information by source document
        sources = {}
        for info in relevant_info:
            doc_name = info.get("doc_name", "Unknown Source")
            if doc_name not in sources:
                sources[doc_name] = []
            sources[doc_name].append(info)
        
        # Build context with clear document separations
        context = "RELEVANT INFORMATION FROM KNOWLEDGE BASE:\n\n"
        
        for doc_name, chunks in sources.items():
            # Add document header
            context += f"=== {doc_name} ===\n"
            
            # Add content from each chunk
            for chunk in chunks:
                context += f"{chunk['content'].strip()}\n\n"
            
            context += "\n"
            
        return context.strip()

    def get_context_for_query(self, query: str) -> str:
        """
        Get relevant context information for a query.
        
        Args:
            query (str): User's query
            
        Returns:
            str: Formatted context information
        """
        relevant_info = self.query_knowledge(query, k=5, similarity_threshold=0.0)
        return self.format_knowledge_context(relevant_info)

    def refresh_learning_data(self):
        """Refresh learning data from MongoDB."""
        print("🔄 Refreshing learning data...")
        self._download_learning_data()
        self.rebuild_index()
        self.initialize_vector_store()
        print("✅ Learning data refreshed successfully!")

    def get_collection_stats(self) -> Dict[str, Any]:
        """Get statistics about the vector store."""
        try:
            if self.vector_store is None:
                return {
                    "total_documents": 0,
                    "collection_name": "aura_learning_data",
                    "mongodb_connected": self.mongodb_client is not None,
                    "faiss_available": False
                }
            
            count = self.vector_store.index.ntotal
            return {
                "total_documents": count,
                "collection_name": "aura_learning_data",
                "mongodb_connected": self.mongodb_client is not None,
                "faiss_available": True
            }
        except Exception as e:
            return {"error": str(e)}

    def close_connection(self):
        """Close MongoDB connection."""
        if self.mongodb_client:
            self.mongodb_client.close()
            print("✅ MongoDB connection closed")
