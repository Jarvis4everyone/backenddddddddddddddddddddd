"""
ChromaDB Service for Learning Data
This module handles vector database operations for AI knowledge enhancement.
"""

import os
from typing import List, Dict, Any, Optional
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from dotenv import load_dotenv

# Try to import ChromaDB, but make it optional
try:
    import chromadb
    from chromadb.config import Settings
    CHROMADB_AVAILABLE = True
except ImportError:
    CHROMADB_AVAILABLE = False
    print("⚠️ ChromaDB not available. Install with: pip install chromadb")

# Load environment variables
load_dotenv()

class ChromaDBService:
    """
    ChromaDB service for managing AI learning data from MongoDB Learning_data collection.
    """
    
    def __init__(self):
        """
        Initialize ChromaDB service and load learning data.
        """
        if not CHROMADB_AVAILABLE:
            print("⚠️ ChromaDB not available. Skipping ChromaDB initialization.")
            self.chroma_client = None
            self.collection = None
            self.mongodb_client = None
            self.db = None
            self.learning_collection = None
            return
        
        self.mongodb_url = os.getenv("MongoDB_URL")
        if not self.mongodb_url:
            raise ValueError("MongoDB_URL not found in environment variables")
        
        # Initialize ChromaDB client
        self.chroma_client = chromadb.Client(Settings(
            persist_directory="./chroma_db",
            anonymized_telemetry=False
        ))
        
        # Get or create collection
        self.collection = self.chroma_client.get_or_create_collection(
            name="aura_learning_data",
            metadata={"description": "AURA chatbot learning data from MongoDB"}
        )
        
        # MongoDB connection for learning data
        self.mongodb_client = None
        self.db = None
        self.learning_collection = None
        self._connect_to_mongodb()
        
        # Load learning data on initialization
        self._load_learning_data()
        
        print("✅ ChromaDB service initialized successfully!")
    
    def _connect_to_mongodb(self):
        """Connect to MongoDB database."""
        if not CHROMADB_AVAILABLE:
            return
            
        try:
            self.mongodb_client = MongoClient(self.mongodb_url, serverSelectionTimeoutMS=5000)
            self.db = self.mongodb_client.aura
            self.learning_collection = self.db.Learning_data
            # Test connection
            self.mongodb_client.admin.command('ping')
            print("✅ Connected to MongoDB for learning data")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            print(f"❌ Failed to connect to MongoDB: {str(e)}")
            raise
    
    def _load_learning_data(self):
        """Load all learning data from MongoDB into ChromaDB."""
        if not CHROMADB_AVAILABLE:
            print("⚠️ ChromaDB not available. Skipping learning data loading.")
            return
            
        try:
            print("🔄 Loading learning data from MongoDB...")
            
            # Clear existing data
            try:
                # Get all existing documents and delete them
                existing_docs = self.collection.get()
                if existing_docs['ids']:
                    self.collection.delete(ids=existing_docs['ids'])
            except Exception as e:
                print(f"⚠️ Warning: Could not clear existing data: {str(e)}")
            
            # Get all documents from Learning_data collection
            documents = list(self.learning_collection.find({}))
            
            if not documents:
                print("⚠️ No learning data found in MongoDB Learning_data collection")
                return
            
            # Prepare data for ChromaDB
            texts = []
            metadatas = []
            ids = []
            
            for i, doc in enumerate(documents):
                # Extract text content from the document
                text_content = self._extract_text_from_document(doc)
                if text_content:
                    texts.append(text_content)
                    metadatas.append({
                        "source": "mongodb_learning_data",
                        "document_id": str(doc.get("_id", i)),
                        "filename": doc.get("filename", f"document_{i}"),
                        "upload_date": str(doc.get("upload_date", "")),
                        "content_type": doc.get("content_type", "text")
                    })
                    ids.append(f"doc_{i}")
            
            if texts:
                # Add documents to ChromaDB
                self.collection.add(
                    documents=texts,
                    metadatas=metadatas,
                    ids=ids
                )
                print(f"✅ Loaded {len(texts)} learning documents into ChromaDB")
            else:
                print("⚠️ No valid text content found in learning documents")
                
        except Exception as e:
            print(f"❌ Error loading learning data: {str(e)}")
            raise
    
    def _extract_text_from_document(self, doc: Dict[str, Any]) -> Optional[str]:
        """Extract text content from a MongoDB document."""
        try:
            # Try different possible field names for text content
            text_fields = ['content', 'text', 'data', 'body', 'description', 'details']
            
            for field in text_fields:
                if field in doc and doc[field]:
                    return str(doc[field])
            
            # If no standard field found, try to extract from the entire document
            # Skip MongoDB-specific fields
            skip_fields = ['_id', 'filename', 'upload_date', 'content_type', 'created_at', 'updated_at']
            content_parts = []
            
            for key, value in doc.items():
                if key not in skip_fields and value:
                    content_parts.append(f"{key}: {value}")
            
            if content_parts:
                return "\n".join(content_parts)
            
            return None
            
        except Exception as e:
            print(f"❌ Error extracting text from document: {str(e)}")
            return None
    
    def search_relevant_info(self, query: str, n_results: int = 5) -> List[Dict[str, Any]]:
        """
        Search for relevant information based on user query.
        
        Args:
            query (str): User's query
            n_results (int): Number of results to return
            
        Returns:
            List[Dict[str, Any]]: Relevant information from learning data
        """
        if not CHROMADB_AVAILABLE or not self.collection:
            return []
            
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=n_results
            )
            
            relevant_info = []
            if results['documents'] and results['documents'][0]:
                for i, doc in enumerate(results['documents'][0]):
                    relevant_info.append({
                        'content': doc,
                        'metadata': results['metadatas'][0][i] if results['metadatas'] else {},
                        'distance': results['distances'][0][i] if results['distances'] else 0
                    })
            
            return relevant_info
            
        except Exception as e:
            print(f"❌ Error searching ChromaDB: {str(e)}")
            return []
    
    def get_context_for_query(self, query: str) -> str:
        """
        Get relevant context information for a query.
        
        Args:
            query (str): User's query
            
        Returns:
            str: Formatted context information
        """
        if not CHROMADB_AVAILABLE:
            return ""
            
        relevant_info = self.search_relevant_info(query, n_results=3)
        
        if not relevant_info:
            return ""
        
        context_parts = []
        for info in relevant_info:
            if info['distance'] < 0.8:  # Only include highly relevant results
                context_parts.append(info['content'])
        
        if context_parts:
            return "\n\nRelevant Information:\n" + "\n\n".join(context_parts)
        
        return ""
    
    def refresh_learning_data(self):
        """Refresh learning data from MongoDB."""
        if not CHROMADB_AVAILABLE:
            print("⚠️ ChromaDB not available. Cannot refresh learning data.")
            return
            
        print("🔄 Refreshing learning data...")
        self._load_learning_data()
        print("✅ Learning data refreshed successfully!")
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """Get statistics about the ChromaDB collection."""
        if not CHROMADB_AVAILABLE:
            return {
                "total_documents": 0,
                "collection_name": "aura_learning_data",
                "mongodb_connected": False,
                "chromadb_available": False
            }
            
        try:
            count = self.collection.count()
            return {
                "total_documents": count,
                "collection_name": "aura_learning_data",
                "mongodb_connected": self.mongodb_client is not None,
                "chromadb_available": True
            }
        except Exception as e:
            return {"error": str(e)}
    
    def close_connection(self):
        """Close MongoDB connection."""
        if self.mongodb_client:
            self.mongodb_client.close()
            print("✅ MongoDB connection closed")
