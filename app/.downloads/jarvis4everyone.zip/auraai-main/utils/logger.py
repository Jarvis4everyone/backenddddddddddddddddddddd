"""
Logging configuration for AURA Backend API.
"""

import logging
import sys
from datetime import datetime

class AURALogger:
    """Custom logger for AURA Backend API."""
    
    def __init__(self, name: str = "AURA"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Remove existing handlers
        for handler in self.logger.handlers[:]:
            self.logger.removeHandler(handler)
        
        # Create console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(name)s | %(message)s',
            datefmt='%H:%M:%S'
        )
        console_handler.setFormatter(formatter)
        
        # Add handler to logger
        self.logger.addHandler(console_handler)
    
    def info(self, message: str):
        """Log info message."""
        self.logger.info(message)
    
    def warning(self, message: str):
        """Log warning message."""
        self.logger.warning(message)
    
    def error(self, message: str):
        """Log error message."""
        self.logger.error(message)
    
    def debug(self, message: str):
        """Log debug message."""
        self.logger.debug(message)
    
    def success(self, message: str):
        """Log success message."""
        self.logger.info(f"✅ {message}")
    
    def startup(self, message: str):
        """Log startup message."""
        self.logger.info(f"🚀 {message}")
    
    def shutdown(self, message: str):
        """Log shutdown message."""
        self.logger.info(f"🔄 {message}")

# Global logger instance
logger = AURALogger()
